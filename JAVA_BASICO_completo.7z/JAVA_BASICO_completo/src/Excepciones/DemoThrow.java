package Excepciones;

public class DemoThrow {
    public static void main(String[] args) {
        try {
            comprobarEdad(17);
        }catch(ArithmeticException e){
            System.out.println("Error " + e.toString());
        }
    }

    static void comprobarEdad(int edad){
        if(edad < 18){
            //System.out.println("Acceso Denegado");
            throw new ArithmeticException("Acceso Denegado");
        }else{
            System.out.println("Acceso Concedido");
        }
    }
}
