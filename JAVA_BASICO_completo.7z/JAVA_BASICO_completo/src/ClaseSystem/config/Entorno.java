package ClaseSystem.config;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

public class Entorno {
    public static void main(String[] args) {
        // Variables del entorno 1 a 1
        System.out.println("usuario = " + System.getProperty("user.name"));
        System.out.println("directorio = " + System.getProperty("user.dir"));
        System.out.println("versiÃ³n Java = " + System.getProperty("java.version"));

        // Todas las variables del entorno
        Properties propiedades = System.getProperties();
        propiedades.list(System.out);

        // Crear variable del sistema
        propiedades.setProperty("config.puerto.servidor","8080");
        System.setProperties(propiedades);
        propiedades.list(System.out);

        // Cargar varibles del sistema desde un archivo
        try {
            FileInputStream archivo = new FileInputStream("src/config.properties");
            propiedades.load(archivo);
            System.setProperties(propiedades);
            propiedades.list(System.out);
        }catch (FileNotFoundException e){
            // Tratamiento del error de FileInputStream
        }catch (IOException e){
            // Tratamiento del error de load
        }

        // Variables de Entorno SO
        Map<String,String> varEntorno = System.getenv();
        System.out.println("varEntorno = " + varEntorno);
        System.out.println("Usuario = " + System.getenv("USERNAME"));
        System.out.println("JAVA HOME = " + System.getenv("JAVA_HOME"));

        for(String clave: varEntorno.keySet()){
            System.out.println("clave = " + clave + " = " + System.getenv(clave));
        }

    }
}
