package ClaseSystem.config;

import java.util.Locale;

//OJO!!! -> Archivo config.properties de Java descargado en la carpeta del paquete

public class EjecutarOS {
        public static void main(String[] args) {
            Runtime rt = Runtime.getRuntime();
            Process proceso;
            try{
                if(System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("windows")){
                    proceso = rt.exec("notepad");
                }else{//linux o mac
                    proceso = rt.exec("gedit");
                }
                proceso.waitFor();
            }catch(Exception e){
                System.err.println("Comando desconocido: " + e.getLocalizedMessage());
                System.exit(1);
            }
            System.out.println("Editor cerrado");
        }
}
