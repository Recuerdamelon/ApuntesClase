package Operadores;

import java.util.Scanner;

public class EjercicioLogin {
    public static void main(String[] args) {
        // 1 - Definir los datos vÃ¡lidos de usuario y password
        String usuario = "eduardo";
        String password = "12345";

        // 2 - Solicitar usuario y password por consola
        Scanner scanner = new Scanner(System.in);
        System.out.print("Usuario: ");
        String us = scanner.next();
        System.out.print("Password: ");
        String pw = scanner.next();
        scanner.close();

        // 3 - Usar solo mÃ©todos de String y lÃ³gicos
//        boolean resultadoUsuario = usuario.equals(us);
//        System.out.println("resultadoUsuario = " + resultadoUsuario);
//        boolean resultadoPassword = password.equals(pw);
//        System.out.println("resultadoPassword = " + resultadoPassword);


        // 4 - El resultado debe ser true si las credenciales introducidas
        // coinciden con los datos vÃ¡lidos o false si no coinciden.
//        boolean login = resultadoUsuario && resultadoPassword;

        boolean login = usuario.equals(us) && password.equals(pw);
        System.out.println("login = " + login);




    }
}
