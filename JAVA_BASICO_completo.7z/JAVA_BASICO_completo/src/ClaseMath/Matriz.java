package ClaseMath;
import java.util.Random;

public class Matriz {
    public static void main(String[] args) {
        // Obtener uno de los colores aleatoriamente
        String[] colores = {"azul", "verde", "rojo", "negro", "blanco", "naranja"};
        // Math.random()
        int indice = (int) (Math.random()* colores.length);//.length ya entrega 6 valores
        System.out.println("colores["+indice+"] = " + colores[indice]);// (de 0 a 5)
        // Clase Random
        Random objetoRnd = new Random();
        indice = objetoRnd.nextInt(colores.length);
        System.out.println("colores["+indice+"] = " + colores[indice]);
        //System.out.println("color = " + colores[objetoRnd.nextInt(colores.length)]);

        Random rnd2 = new Random(46546092);
    }
}
