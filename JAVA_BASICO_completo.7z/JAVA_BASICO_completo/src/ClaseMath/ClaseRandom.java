package ClaseMath;
import java.util.Random;

public class ClaseRandom {
    public static void main(String[] args) {
//        // Generar entero aleatorio comprendido 0 .. 90
//        for(int i = 0; i < 100; i++) {
//            int n = (int) (Math.random() * 91); //91 = 90+1
//            // 0 .. 0.9999999999 -> * 91 = 0 .. 90.99999 -> (int) = 0 .. 90
//            System.out.println("n = " + n);
//        }
//
//        // BINGO -> 1 .. 90
//        // SoluciÃ³n 1
//        for(int i = 0; i < 100; i++) {
//            int n = (int) (Math.random() * (91)); //91 = 90+1 // 0 .. 90
//            if(n != 0) {
//                System.out.println("n = " + n);
//            }
//        }
//        //SoluciÃ³n 2
//        for(int i = 0; i < 100; i++) {
//            int n = (int) (Math.random() * 90) + 1; // (0 .. 89)+1 -> 1 .. 90
//            System.out.println("n = " + n);
//        }
//
//        //SoluciÃ³n 3
//        for(int i = 0; i < 100; i++) {
//            int n = (int) Math.ceil((Math.random() * 90));
//            if(n != 0) {
//                System.out.println("n = " + n);
//            }
//        }

        // La clase Random de java.util
        Random objetoRnd = new Random();
        int numInt = objetoRnd.nextInt();
        System.out.println("numInt = " + numInt);
        long numLong = objetoRnd.nextLong();
        System.out.println("numLong = " + numLong);
        float numFloat = objetoRnd.nextFloat();
        System.out.println("numFloat = " + numFloat);

        //Rangos 0 .. n
        numInt = objetoRnd.nextInt(91); // n + 1 -> 0 .. 91
        System.out.println("numInt = " + numInt);
        numLong = objetoRnd.nextLong(18000);
        System.out.println("numLong = " + numLong);
        numFloat = objetoRnd.nextFloat(58);
        System.out.println("numFloat = " + numFloat);

        //Rangos n .. m
        numInt = objetoRnd.nextInt(1,91); // n + 1 --> 90 +1
        System.out.println("numInt = " + numInt);
        numLong = objetoRnd.nextLong(18000,18100);
        System.out.println("numLong = " + numLong);
        numFloat = objetoRnd.nextFloat(58, 65);
        System.out.println("numFloat = " + numFloat);

        // 48 .. 90
        numInt = 48 + objetoRnd.nextInt(90 - 48 + 1);
        System.out.println("numInt = " + numInt);
    }
}