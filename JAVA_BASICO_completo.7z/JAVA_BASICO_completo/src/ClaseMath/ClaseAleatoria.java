package ClaseMath;

import java.util.Random;

public class ClaseAleatoria {
    public static void main(String[] args) {
        System.out.println("la clave es = " + generaClave(15));
    }

    public static String generaClave(int longitud){
        Random objRnd = new Random();
        String base = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789&$%_";
        String clave = "";
        int n = 0;
        for(int i = 0; i < longitud; i++){
            n = objRnd.nextInt(base.length());
            clave += base.charAt(n);
        }
        return clave;
    }
}
