package ExpresionesLambda;

public interface FuncionNumeros {
    int ejecuta(int j, int k);
}
