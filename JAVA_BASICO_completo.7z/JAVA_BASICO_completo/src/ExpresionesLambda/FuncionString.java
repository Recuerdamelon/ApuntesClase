package ExpresionesLambda;

public interface FuncionString {
    String ejecuta(String str);
}
