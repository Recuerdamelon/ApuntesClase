package ExpresionesLambda;
import java.util.ArrayList;
import java.util.function.Consumer;

public class EjemploLambda {
    public static void main(String[] args) {
        FuncionString exclamacion = (s)->"Â¡" + s + "!";
        FuncionString interrogacion = (s)->"Â¿" + s + "?";
        imprimeFormato("Un texto",exclamacion);
        imprimeFormato("Otro texto", interrogacion);
        System.out.println("-------------------------------------");

        FuncionNumeros suma = (n1,n2)-> n1 + n2;
        imprimeSuma(6,9,suma);

        ArrayList<Integer> cifras = new ArrayList();
        cifras.add(89);
        cifras.add(8);
        cifras.add(9);
        cifras.add(25);

        cifras.forEach((n)-> System.out.println("n = " + n));

        cifras.forEach((num)-> {
            if(num != 89) {
                num = num * 2;
            }
            System.out.println("num = " + num);
        });

        System.out.println("-------------------------------------");
        Consumer numerar = (n)-> System.out.println("n = " + n);
        cifras.forEach(numerar);


    }

    public static void imprimeFormato(String str, FuncionString formato){
        String resultado = formato.ejecuta(str);
        System.out.println("resultado = " + resultado);
    }

    public static void imprimeSuma(int a, int b, FuncionNumeros f){
        System.out.println("resultado = " + f.ejecuta(a,b));
    }

}
