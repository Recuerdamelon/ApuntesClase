package Variables;

public class SistemasNumericos {
    public static void main(String[] args) {
        int numDecimal = 14;
        System.out.println("numDecimal = " + numDecimal);

        int numBinario = 0b00001110;
        System.out.println("numBinario = " + numBinario);

        int numOctal = 016;
        System.out.println("numOctal = " + numOctal);

        int numHexadecimal = 0x0E;
        System.out.println("numHexadecimal = " + numHexadecimal);

    }
}
