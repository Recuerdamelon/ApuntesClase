package DateYCalendar;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EjemploDate {
    public static void main(String[] args) {
        Date fecha = new Date();
        System.out.println("fecha = " + fecha);
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy KK:mm:ss a");
        String fechaFormateada = formato.format(fecha);
        System.out.println("fechaFormateada = " + fechaFormateada);

        long momento1 = fecha.getTime();
        System.out.println("momento1 = " + momento1);
        int a = 0;
        for(int i = 0; i < 1000; i++){
            a = i;
        }

        Date fecha1 = new Date();
        long momento2 = fecha1.getTime();
        System.out.println("Diferencia = " + (momento2 - momento1) + " ms");
    }
}
