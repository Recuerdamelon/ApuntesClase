package DateYCalendar;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class FechaDePago {
    public static void main(String[] args) {
        // Establecemos las condiciones de pago (30,60,90,120) dias
        // Calculamos vencimiento del pago y lo imprimimos con formato dd-mm-aaaa

        System.out.println(vencimiento(90));

    }

    public static String vencimiento(int plazo){
//        Calendar calendario = Calendar.getInstance();
//        Date hoy = calendario.getTime();
//        SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
//        String fechaFormateada = formato.format(hoy);
//        String strDia = fechaFormateada.substring(0,2);
//        //System.out.println("strDia = " + strDia);
//        int dia = Integer.parseInt(strDia);
//        int mes = Integer.parseInt(fechaFormateada.substring(3,5));
//        int anno = Integer.parseInt(fechaFormateada.substring(6));
//        //System.out.println("dia + \" \" + mes + \" \" +anno = " + dia + " " + mes + " " +anno);
//        calendario.set(anno, mes - 1, dia + plazo);
//        Date vencimiento = calendario.getTime();
//        return formato.format(vencimiento);

        // Simplificando
        Calendar calendario = Calendar.getInstance();
        Date hoy = calendario.getTime();
        SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
        String fechaFormateada = formato.format(hoy);
        int dia = Integer.parseInt(fechaFormateada.substring(0,2));
        calendario.set(Calendar.DATE, dia + plazo);
        Date vencimiento = calendario.getTime();
        return formato.format(vencimiento);
    }
}