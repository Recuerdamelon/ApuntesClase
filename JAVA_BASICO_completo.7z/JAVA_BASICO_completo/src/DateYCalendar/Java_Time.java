package DateYCalendar;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;

public class Java_Time {
    public static void main(String[] args) {
        // Fecha
        LocalDate objetoFecha = LocalDate.now();
        System.out.println("objetoFecha = " + objetoFecha);

        // Formato dd/MM/yyyy
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("objetoFecha = " + objetoFecha.format(formatoFecha));

        // Hora
        LocalTime objetoHora = LocalTime.now();
        System.out.println("objetoHora = " + objetoHora);

        // Formato
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("hh:mm:ss");
        System.out.println("objetoHora = " + objetoHora.format(formatoHora));

        // Fecha y hora
        LocalDateTime objetoFechaHora = LocalDateTime.now();
        DateTimeFormatter formatoFechaHora = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss a");
        System.out.println("objetoFechaHora = " + objetoFechaHora.format(formatoFechaHora));

        // Establecer Fecha y Hora
        objetoFechaHora = LocalDateTime.of(2020,5,12,18,8,0);
        System.out.println("objetoFechaHora = " + objetoFechaHora.format(formatoFechaHora));

        objetoFechaHora = LocalDateTime.of(2020, Month.MAY,12,18,8,0);
        System.out.println("objetoFechaHora = " + objetoFechaHora.format(formatoFechaHora));

    }
}
