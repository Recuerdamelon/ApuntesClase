package DateYCalendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EjemploCalendar {
    public static void main(String[] args) {
        Calendar calendario = Calendar.getInstance();
        Date fecha = calendario.getTime();
        System.out.println("Fecha = " + fecha);
        calendario.set(Calendar.YEAR,2020);
        calendario.set(Calendar.MONTH,Calendar.JUNE);
        Date fecha1 = calendario.getTime();
        System.out.println("Fecha = " + fecha1);
        calendario.set(2013,Calendar.AUGUST,1,9,15,23);
        Date fecha2 = calendario.getTime();
        System.out.println("fecha2 = " + fecha2);
        // Formato de fecha
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String fechaFormateada = formato.format(fecha2);
        System.out.println("fechaFormateada = " + fechaFormateada);

        // Asignar fecha desde String
        try{
            Date fecha3 = formato.parse("27/04/2021");
            System.out.println("fecha3 = " + formato.format(fecha3));
            if(fecha3.compareTo(fecha2) > 0){
                System.out.println("fecha3.compareTo(fecha2) =" + fecha3.compareTo(fecha2));
                System.out.println("fecha3.compareTo(fecha2) = 3 mayor que 2");
            }
            if(fecha3.compareTo(fecha) > 0){
                System.out.println("fecha3.compareTo(fecha2) = 3 mayor que 2");
            }else{
                System.out.println("fecha3.compareTo(fecha) = fecha3 menor que fecha");
            }

        }catch(ParseException e){
            e.printStackTrace();
        }

    }
}
