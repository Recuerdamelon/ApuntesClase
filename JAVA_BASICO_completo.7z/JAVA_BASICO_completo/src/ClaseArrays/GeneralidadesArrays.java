package ClaseArrays;

public class GeneralidadesArrays {
    public static void main(String[] args) {
        // declarar
        String[] colores1 = {"azul", "rojo", "verde", "amarillo", "naranja"};

        String[] colores2 = new String[5]; // valores null
        //colores2[0] = "azul"; //asignar 1 a 1.

//        // copiar una matriz en otra// bucle for para introducir datos...
//        for(int i = 0; i < colores1.length; i++){
//            colores2[i] = colores1[i];
//            System.out.println("colores2["+i+"] = " + colores2[i]);
//        }

        // inversa
        // colores1[0] -> colores2[4]
        // colores1[1] -> colores2[3]
        // colores1[2] -> colores2[2]
        // colores1[3] -> colores2[1]
        // colores1[4] -> colores2[0]
        int k = 0;
        while (k < colores1.length){
            int indice = colores2.length - 1 - k;//length de la matriz es 5, de 0 a 4 a través de -1
            colores2[indice] = colores1[k];// k va de 0 a length (+1 con cada iteración)
                                                //al restarlo a length tenemos la inversa
            System.out.println("colores2[" + (indice) +"] = " + colores2[indice]);
//            System.out.println("k = " + k + " -> indice = " + indice);
            k++;
        }

    }
}

