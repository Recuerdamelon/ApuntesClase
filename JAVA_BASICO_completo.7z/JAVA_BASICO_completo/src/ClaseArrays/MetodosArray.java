package ClaseArrays;
import java.util.Arrays;

public class MetodosArray {
    public static void main(String[] args) {
        String[] colores = {"azul", "rojo", "verde", "amarillo", "naranja"};
        int[] numeros = {1,2,3,4,5,6};
        int[] numeros1 = {2,8,3,4,5,9};


        // Buscar
        System.out.println(Arrays.binarySearch(numeros,6));
        System.out.println(Arrays.binarySearch(colores,"verde"));

        // Ordenar
        for(String color:colores){
            System.out.println("color = " + color);
        }
        //Arrays.sort(colores,2,5);//Alfabéticamente //podemos añadir índice de afectación
        Arrays.sort(colores);
        for(String color:colores){
            System.out.println("color = " + color);
        }

        // Comparar
        System.out.println("Arrays.equals -> " + Arrays.equals(numeros,numeros1));//mismo contenido -> true
        System.out.println("Arrays.compare -> " + Arrays.compare(numeros1,numeros));// compare(a,b) -> mismo contenido -> 0
        //distinto (-1) a<b  ||  (1) a>b
        //      Podemos añadir rango al compare...
        System.out.println("Arrays.compare con rango -> " + Arrays.compare(numeros1,1,5,numeros,1,5));

        // Copiar
        int[] copia = Arrays.copyOf(numeros,4);

        for(int n:copia){
            System.out.println("n = " + n);
        }
        System.out.println("----------------------");
        //...copiar un rango de valores
        int[] copiaRango = Arrays.copyOfRange(numeros,2,5);
        for(int n:copiaRango){
            System.out.println("n = " + n);
        }
        System.out.println("----------------------");
        // Rellenar
        int[] miMatriz = new int[8];
        Arrays.fill(miMatriz,5);
        for(int n:miMatriz){
            System.out.println("n = " + n);
        }
        System.out.println("----------------------");
        // Bidimensional
        int[][] bidi = new int[3][4];//3 filas y 4 columnas
        System.out.println("----------------------");
        bidi[0][0] = 4;//....
        int[][] bidi1 = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};//Otra manera de hacerlo...
        System.out.println("bidi1[1][2] = " + bidi1[1][2]);//recuerda, empezamos en 0
        for(int i = 0; i< bidi1.length; i++){
            for(int k = 0; k < bidi1[i].length; k++){
                System.out.println("bidi1["+i+"]["+k+"] = " + bidi1[i][k]);
            }
        }
        System.out.println("----------------------");
        // Segunda dimension variable
        int[][] dos = new int[3][];//3 columnas, filas sin definir
        dos[0] = new int[4];//Establecemos distinto número de filas para cada columna
        dos[1] = new int[6];
        dos[2] = new int[5];

        int[][] bidi2 = {{1,2,3,4},{5,6,7,8,9,10},{11,12,13,14,15}};//Otra manera de hacerlo
        for(int i = 0; i< bidi2.length; i++){//Mismo bloque for para recorrer la matriz
            for(int k = 0; k < bidi2[i].length; k++){
                System.out.println("bidi2["+i+"]["+k+"] = " + bidi2[i][k]);
            }
        }

    }
}
