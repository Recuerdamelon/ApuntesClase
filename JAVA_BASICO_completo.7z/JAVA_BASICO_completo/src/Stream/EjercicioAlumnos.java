package Stream;
import java.util.Arrays;
import java.util.stream.Stream;

public class EjercicioAlumnos {
    // Crear un Stream a partir de varios alumnos del archivo alumnos1.csv
    // Filtrar resultados por distintas bÃºsquedas:
    // Por nombre
    // Por apellido
    // Por grupos ...

    public static void main(String[] args) {
        String[] alumnosBase = {"2201;1;Acedo Castro;Alfonso;a-castro92@hotmail.com",
                "2202;1;Jiménez Carrasco;Antonia;antoniajcarrasco@gmail.com",
                "2203;2;AGUDO CASTAÑO;CRISTIAN;cristianencinasola@hotmail.com"};

        Stream<String[]> alumnos = Arrays.stream(alumnosBase)
                .map(n -> n.split(";"));


        // Seleccionar por qué campo quiero buscar
        int campo = 4; // Email
        String busqueda = "hotmail";
        alumnos.filter(alum -> alum[campo].contains(busqueda))
                .forEach(alum -> System.out.println("alumno --> " + alum[3] + " " + alum[2] + " --> " + alum[4]));

    }

}