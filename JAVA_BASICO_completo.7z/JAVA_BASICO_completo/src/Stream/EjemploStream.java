package Stream;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class EjemploStream  {
    public static void main(String[] args) {
        /////////////////////////////////////////////////CREAR/////////////////////////////////////////////
        // Crear directamente
        Stream<String> nombres = Stream.of("María","José","Juan","Marta");
        //Dos opciones de procesar el Stream -> #1 Expresiones Lambda / #2 Expresiones de clase
        //nombres.forEach(n -> System.out.println(n));
        //nombres.forEach(System.out::println);
        System.out.println("--------------------------------");

        // Crear desde array
        String[] arrnom = {"María","José","Juan","Marta"};
        Stream<String> nombres1 = Arrays.stream(arrnom);
        nombres1.forEach(System.out::println);
        System.out.println("--------------------------------");

        // Stream builder
        Stream<String> nombres2 = Stream.<String>builder()
                .add("María")
                .add("Marta")
                .add("José")
                .add("Juan")
                .build();

        nombres2.forEach(System.out::println);
        System.out.println("--------------------------------");

        ///////////////////////////////////////OPERADOR MAP/////////////////////////////////////////////
        // Operador map
        Stream<String> nombres3 = Stream.of("María","José","Juan","Marta")
                //.peek(nom -> System.out.println("nom = " + nom)) // Inspección
                .map(nom -> nom.toUpperCase())
                //.peek(nom -> System.out.println("nom = " + nom)) // Inspección)
                .map(String::toLowerCase)
                //.peek(nom -> System.out.println("nom = " + nom)); // Inspección
                ;
        nombres3.forEach(System.out::println);
        System.out.println("--------------------------------");

        ///////////////////////////////////////CONVERTIR/////////////////////////////////////////////
        // Convertir en colección
        List<String> lista = nombres3.collect(Collectors.toList());
        lista.forEach(n -> System.out.println(n));
        System.out.println("--------------------------------");

        System.out.println("****************************EJERCICIO USUARIO******************************");
        // Creando objetos Usuario
        Stream<Usuario> nombres4 = Stream.of("María","José","Juan","Marta")
                .map(nombre -> new Usuario(nombre,null,null))
                .peek(usuario -> System.out.println("usuario.getNombre() = " + usuario.getNombre()))
                .map(usuario -> {
                    String nombre = usuario.getNombre().toUpperCase();
                    usuario.setNombre(nombre);
                    return usuario;
                });
        //nombres4.forEach(usuario -> System.out.println("usuario = " + usuario.getNombre() + " " + usuario.getApellido()));

        // Convertir en lista
        List<Usuario> listaUsuarios = nombres4.collect(Collectors.toList());
        listaUsuarios.forEach(u -> System.out.println(u.getNombre() + " " + u.getApellido()));


        Stream<Usuario> nombres5 = Stream.of("Pérez Martín; María; maria@eoi.es",
                        "García Solas; José; jose@eoi.es",
                        "Suarez Mel; Juan; juan@eoi.es",
                        "Diaz Fernández; Marta; marta@eoi.es")
                .map(linea -> {//Podemos añadir bloques de instrucciones al .map
                    String[] campos = linea.split(";");//split elementos cada ';' en un contenedor
                    Usuario usuario = new Usuario(campos[1],campos[0],campos[2]);
                    return usuario;
                })
                .map(usuario -> {
                    String nombre = usuario.getNombre().toUpperCase();
                    usuario.setNombre(nombre);
                    return usuario;
                });

        // Convertir en lista
        List<Usuario> listaUsuarios1 = nombres5.collect(Collectors.toList());
        //listaUsuarios1.forEach(u -> System.out.println(u.getNombre() + " " + u.getApellido() + " -> " + u.getEmail()));
        listaUsuarios1.forEach(u -> System.out.println(u.toString()));

        System.out.println("****************************FILTER******************************");
        // Filter
        Stream<String> nombres6 = Stream.of("María","José","Juan","Marta")
                //.filter(nom -> nom.equals("Juan")
                .filter(nom->nom.contains("a") && nom.contains("M"))
                .filter(nom->nom.contains("t"));

        nombres6.forEach(n->System.out.println(n));

        ///////////////////////// anyMatch y allMatch
        // al menos uno coincide
        boolean nombres7 = Stream.of("María","José","Juan","Marta")
                .map(n -> n.toUpperCase())
                .anyMatch(n -> n.contains("A"));

        System.out.println("nombres7 = " + nombres7);

        // todos los elementos cumplen la condición
        boolean nombres8 = Stream.of("María","José","Juan","Marta")
                .map(n -> n.toUpperCase())
                .allMatch(n -> n.contains("A"));

        System.out.println("nombres8 = " + nombres8);

        /////////////////////////////// Count
        long contador = Stream.of("María","José","","Juan","","Marta")
                .filter(n -> !n.isEmpty())
                .filter(n -> n.contains("a"))
                .count();

        System.out.println("contador = " + contador);

        ///////////////////////////// Distinct
        Stream<String> nombres9 = Stream.of("María","María","José","Juan","Juan","Juan","Marta")
                .distinct();
        nombres9.forEach(System.out::println);

        ///////////////////////////// Reduce
        Stream<String> nombres10 = Stream.of("María","José","Juan","Marta")
                .map(n -> n.toUpperCase());

        System.out.println(nombres10.reduce("El resultado es = ", (a,b) -> a + b + "; "));


        // Enteros
        // Reduce y Sum

        Stream<Integer> numeros = Stream.of(5,10,15,20,25);

        //int resultado = numeros.reduce(0,(a,b) -> a + b);
        int resultado = numeros.reduce(1,(a,b) -> a * b);

        //int resultado = numeros.reduce(0,Integer::sum);
        System.out.println("resultado = " + resultado);

        // Rangos numéricos
        //IntStream numeros1 = IntStream.range(5,20) // 5..19
        IntStream numeros1 = IntStream.rangeClosed(5,20) // 5..20
                .peek(System.out::println);

        System.out.println("numeros1.sum() = " + numeros1.sum());

        // Estadística
        IntStream numeros2 = IntStream.rangeClosed(5,20) // 5..20
                .peek(System.out::println);

        IntSummaryStatistics estadisticas = numeros2.summaryStatistics();
        System.out.println("max: " + estadisticas.getMax());
        System.out.println("min: " + estadisticas.getMin());
        System.out.println("suma: " + estadisticas.getSum());
        System.out.println("media: " + estadisticas.getAverage());
        System.out.println("cuenta: " + estadisticas.getCount());
        System.out.println("resumen: " + estadisticas.toString());

    }
}
