package Stream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class EjerciciointStream {
    public static void main(String[] args) {
        // Crear un Stream de números enteros
        // Obtener la suma de todos los números pares/impares
        // que haya en origen de datos

        Stream<Integer> numeros = Stream.of(5,10,15,20,25)
                //.filter(n -> n % 2 == 0)  //pares
                .filter(n -> n % 2 != 0)  //impares
                .peek(System.out::println);

        //int resultado = numeros.reduce(0,(a,b) -> a + b);
        //int resultado = numeros.reduce(0,Integer::sum);
        //System.out.println("resultado = " + resultado);

        long cuenta = numeros.count();
        System.out.println("cuenta = " + cuenta);

    }
}
