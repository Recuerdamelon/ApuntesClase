package Stream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Stream;

public class EjercicioAlumnos3 {
    //////////EN ESTA VARIANTE DEL EJERCICIO INTRODUCIMOS EL CONTENIDO DEL ARCHIVO DIRECTAMENTE AL STREAM,//////////////
    /////////////////////// SIN NECESIDAD DE CREAR ANTES UN ARRAY DESDE EL QUE PASARLE LOS DATOS  ///////////////
    public static void main(String[] args) {
        String campo= "";
        String busqueda = "";
        String archivo = "alumnos1.csv";

        do {
            campo = leerEntrada("id, grupo, apellido, nombre, email o salir: ");
            if(!campo.contains("salir"))
                busqueda = leerEntrada("Buscar: ");
            buscaEnCsv(archivo, campo, busqueda);
        } while(!campo.equals("salir"));
    }

    public static void buscaEnCsv(String archivo, String campo, String busqueda){
        try {
            Stream<Alumno> alumnos = Files.lines(Paths.get(archivo))
                    .map(n -> n.split(";"))
                    .map(n -> new Alumno(n[0],n[1],n[2],n[3],n[4]));

            switch(campo){
                case "id":
                    alumnos.filter(n -> n.getId().equals(busqueda)).forEach(n -> System.out.println(n.toString()));
                    break;
                case "apellido":
                    alumnos.filter(n -> n.getAppellido().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                    break;
                case "nombre":
                    alumnos.filter(n -> n.getNombre().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                    break;
                case "email":
                    alumnos.filter(n -> n.getEmail().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                    break;
                case "grupo":
                    alumnos.filter(n -> n.getGrupo().equals(busqueda)).forEach(n -> System.out.println(n.toString()));
                    break;
                case "salir":
                    System.out.println("");
                    System.out.println("");
                    break;
                default:
                    System.out.println("Campo de búsqueda no valido");

            }
            System.out.println("");
        }catch (IOException e){
            System.out.println(e.getStackTrace());
        }
    }



    public static String leerEntrada(String mensaje){
        Scanner entrada = new Scanner(System.in);
        System.out.println(mensaje);
//        String dato = entrada.nextLine();
//        return dato;
        return entrada.nextLine();
    }
}
