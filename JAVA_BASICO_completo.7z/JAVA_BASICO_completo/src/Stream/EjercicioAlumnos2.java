package Stream;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class EjercicioAlumnos2 {
    // Crear un Stream a partir de varios alumnos del archivo alumnos1.csv
    // Filtrar resultados por distintas bÃºsquedas:
    // Por nombre
    // Por apellido
    // Por grupos ...
    public static void main(String[] args) {
//       Ahora introduciendo datos desde archivo dado en csv

        String[] alumnosBase = leerCsv("alumnos1.csv");

        String campo= "";
        String busqueda = "";

        do {
            campo = leerEntrada("id, grupo, apellido, nombre, email o salir: ");
            if(!campo.contains("salir"))
                busqueda = leerEntrada("Buscar: ");
            buscaEnStream(alumnosBase, campo, busqueda);
        } while(!campo.equals("salir"));
    }

    public static String[] leerCsv(String archivo){
        List<String> contenido = new ArrayList<String>();
        try {
            File miArchivo = new File(archivo);
            Scanner leer = new Scanner(miArchivo);
            while (leer.hasNextLine()){
                contenido.add(leer.nextLine());
            }
            leer.close();
        }catch(FileNotFoundException e){
            System.out.println(e.getStackTrace());
        }
        return contenido.toArray(new String[contenido.size()]);
    }

    public static String leerEntrada(String mensaje){
        Scanner entrada = new Scanner(System.in);
        System.out.println(mensaje);
//        String dato = entrada.nextLine();
//        return dato;
        return entrada.nextLine();
    }

    public static void buscaEnStream(String[] datosFuente, String campo, String busqueda){
        Stream<Alumno> alumnos = Arrays.stream(datosFuente)
                .map(n -> n.split(";"))
                .map(n -> new Alumno(n[0],n[1],n[2],n[3],n[4]));
        // Otra forma
//                .map(n -> {
//                    String[] aux  = n.split(";");
//                    Alumno alumno = new Alumno(aux[0],aux[1],aux[2],aux[3],aux[4]);
//                    return alumno;
//                });

        switch(campo){
            case "id":
                alumnos.filter(n -> n.getId().equals(busqueda)).forEach(n -> System.out.println(n.toString()));
                break;
            case "apellido":
                alumnos.filter(n -> n.getAppellido().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                break;
            case "nombre":
                alumnos.filter(n -> n.getNombre().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                break;
            case "email":
                alumnos.filter(n -> n.getEmail().contains(busqueda)).forEach(n -> System.out.println(n.toString()));
                break;
            case "grupo":
                alumnos.filter(n -> n.getGrupo().equals(busqueda)).forEach(n -> System.out.println(n.toString()));
                break;
            case "salir":
                System.out.println("");
                System.out.println("");
                break;
            default:
                System.out.println("Campo de bÃºsqueda no valido");

        }
        System.out.println("");
    }
}
