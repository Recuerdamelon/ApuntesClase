package Stream;

//CLASE CONSTRUCTORA DE ATRIBUTOS
public class Alumno {
    private String id;
    private String grupo;
    private String apellido;
    private String nombre;
    private String email;


    public Alumno(String id, String grupo, String apellido, String nombre, String email) {
        this.id = id;
        this.grupo = grupo;
        this.apellido = apellido;
        this.nombre = nombre;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public String getGrupo() {
        return grupo;
    }

    public String getAppellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return   "ID -> " + id +
                "|| GRUPO - >  "+ grupo +
                "|| " + apellido +
                ", " + nombre +
                "|| EMAIL -> " + email;
    }
}
