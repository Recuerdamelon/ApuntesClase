package EstructurasDeControl;

public class ComentariosNotas {
    public static void main(String[] args) {
        // Si nota < 5 -> mensaje " a esforzarse"
        // Si nota = (5-6) -> mensaje " a mejorar"
        // Si nota = (7-8) -> mensaje " estÃ¡ bien, busca la excelencia"
        // Si nota = (9-10) -> mensaje " Estupendo"

        // Estructura if..else if
        int nota = 6;

        if (nota < 5) {
            System.out.println("a esforzarse");
        } else if (nota <= 6) {
            System.out.println("a mejorar");
        } else if (nota <= 8) {
            System.out.println("estÃ¡ bien, busca la excelencia");

        } else {
            System.out.println("Estupendo");
        }

        // Estructura switch
        switch (nota) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                System.out.println("a esforzarse");
                break;
            case 5:
            case 6:
                System.out.println("a mejorar");
                break;
            case 7:
            case 8:
                System.out.println("estÃ¡ bien, busca la excelencia");
                break;
            case 9:
            case 10:
                System.out.println("Estupendo");
                break;
            default:
                System.out.println("La nota no estÃ¡ entre 0 y 10");
        }
    }
}
