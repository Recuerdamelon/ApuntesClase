package EstructurasDeControl;

public class EjemploSwitch {
    public static void main(String[] args) {
        int mes = 4;
        String nombreMes = "";
        switch (mes){
            case 1:
                nombreMes = "enero";
                break;
            case 2:
                nombreMes = "febrero";
                break;
            case 3:
                nombreMes = "marzo";
                break;
            case 4:
                nombreMes = "abril";
                break;
            case 5:
                nombreMes = "mayo";
                break;
            default:
                nombreMes = "despues de mayo";
        }
        System.out.println("nombreMes = " + nombreMes);


        if(mes == 1){
            nombreMes = "enero";
        }else if(mes == 2){
            nombreMes = "febrero";
        }else if(mes == 3){
            nombreMes = "marzo";
        }else{
            nombreMes = "despues de marzo";
        }
        System.out.println("nombreMes = " + nombreMes);
    }
}
