package EstructurasDeControl;

public class EjemploFor {
    public static void main(String[] args) {
        // Mostrar del 1 al 20 con distientos incrementos
        // Incremento 1
        for(int i = 1; i <= 20; i++){
            System.out.println("i = " + i);
        }

        // Incremento 2
        for(int i = 1; i <= 20; i = i + 2){
            System.out.println("i = " + i);
        }

        // Incremento 5
        for(int i = 0; i <= 20; i = i + 5){
            System.out.println("i = " + i);
        }

        // Suma 0 a 20
        int suma = 0;
        for(int i = 0; i <= 20; i++){
            //suma = suma + i;
            suma += i;
        }
        System.out.println("suma = " + suma);

        // Factorial
        int num = 6;
        int factorial = 1;
        for(int i = 1; i <= num; i++){
            factorial *= i;
        }
        System.out.println("factorial = " + factorial);

        factorial = 1;
        for(int i = num; i > 0; i--){
            factorial *= i;
        }
        System.out.println("factorial = " + factorial);

        // Mostrar ASCII del 65 al 90
        char caracter = 'a';
        for(int i = 65; i <= 90; i++){
            caracter = (char) i;
            System.out.println("caracter = " + caracter);
        }

        // Recorrer matriz
        String[] coches = {"Volvo","Renault","Seat","Citroen"};
        for(int i = 0; i < coches.length; i++){
            System.out.println("coches = " + coches[i]);
        }

        // Recorrer matriz bidimensional
        int[][] enteros = {{1,2,3,7},{4,5,6,7},{7,8,9,4}};

        for(int i = 0; i < enteros.length; i++){
            for(int j = 0; j < enteros[i].length; j++){
                System.out.println("entero["+i+"]["+j+"] = " + enteros[i][j]);
            }
        }


        // For each
        for(String marca: coches){
            System.out.println("marca = " + marca);
        }

        // Convertir las marcas en mayÃºsculas
        for(String marca: coches){
            System.out.println("marca = " + marca.toUpperCase());
        }

        // Sumar elementos de una matriz de enteros
        int[] num2 = {1,5,67,89,88};
        int suma1 = 0;
        for(int n:num2){
            suma1 += n;
        }
        System.out.println("suma1 = " + suma1);

        // While
        // Mostrar nÃºmeros
        int contador = 0;
        while(contador <= 20){
            System.out.println("contador = " + contador);
            contador++;
        }

        // Mostrar coches
        contador = 0;
        while (contador < coches.length){
            System.out.println("coches = " + coches[contador]);
            contador++;
        }

        // Mostrar coches hasta que llegue Seat
        contador = 0;
        while (coches[contador] != "Seat"){
            System.out.println("coches = " + coches[contador]);
            contador++;
        }

        // do..while
        contador = 0;
        do{
            System.out.println("contador = " + contador);
            contador++;
        }while(contador < 20);

        contador = 0;
        do{
            System.out.println("coches = " + coches[contador]);
            contador++;
        }while(coches[contador] != "Seat");
        System.out.println("**********************************************");

        // Break
        //for(int i = 0; i< 5; i++) {
        for (String marca : coches) {
            if (marca == "Seat") {
                break;
            }
            System.out.println("marca = " + marca);
        }
        //}
        System.out.println("**********************************************");

        // Continue
        for (String marca : coches) {
            if (marca == "Seat") {
                continue;
            }
            System.out.println("marca = " + marca);
        }

        System.out.println("**********************************************");
    }
}
