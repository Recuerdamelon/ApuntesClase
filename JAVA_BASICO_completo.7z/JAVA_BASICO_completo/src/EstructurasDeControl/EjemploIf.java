package EstructurasDeControl;

import java.util.Scanner;

public class EjemploIf {
    public static void main(String[] args) {
        // 1 - Definir los datos vÃ¡lidos de usuario y password
        String usuario = "eduardo";
        String password = "12345";

        // 2 - Solicitar usuario y password por consola
        Scanner scanner = new Scanner(System.in);
        System.out.print("Usuario: ");
        String us = scanner.next();
        System.out.print("Password: ");
        String pw = scanner.next();
        //scanner.close();

        boolean login = usuario.equals(us) && password.equals(pw);
        // System.out.println("login = " + login);

        // Con IF
//        if(usuario.equals(us) && password.equals(pw)){
//            System.out.println("Has accedido al programa");
//        }else {
//            System.out.println("Credenciales erroneas");
//        }

        if(login){
            System.out.println("Has accedido al programa");
        }else {
            System.out.println("Credenciales erroneas");
            main(args);
            System.exit(0);
        }


//        // if .. else if
//        int a = 2;
//        int b = 2;
//        int c = 2;
//
//        if(a < b){
//            System.out.println("a < b");
//        }else if(b < c){
//            System.out.println("b < c");
//        }else{
//            System.out.println("AquÃ­");
//        }

    }
}
