package ClasesWrapper;

public class Wrapper {
    public static void main(String[] args) {
        Integer i = Integer.valueOf(123456);//Convertido en OBJETO, con métodos aplicables
        //Integer i = 123456;Otra manera de crear i
        Integer e = 123456;
        System.out.println(e == i);
        System.out.println("i = " + i);
        String s = i.toString();
        System.out.println("s = " + s);
        //Métodos del objeto
        int j = i.intValue();
        //Métodos de la clase
        long l = i.longValue();
        float f = i.floatValue();
        double d = i.doubleValue();
        int k = Integer.parseInt("1223141");
        System.out.println("To HEX = " + Integer.toHexString(1241234));
        System.out.println("To OCT = " + Integer.toOctalString(1241234));
        System.out.println("To BIN = " + Integer.toBinaryString(13213));

        // Long
        Long varlong = 123525646464L; //Es un objeto, Long empieza en mayúsculas
        String str = varlong.toString();
        d = varlong.doubleValue();
        long vlong = Long.parseLong("4534547456");
        System.out.println("bits = " + Long.bitCount(1239120309));

        // Char
        Character c = Character.valueOf('1');
        System.out.println("charValue() " + c.charValue());
        System.out.println("isDigit " + c.isDigit(c));
        char b = 'D';
        System.out.println("isDigit " + Character.isDigit(b));
        System.out.println("valueOf " + Character.valueOf(b));
        b = Character.toLowerCase(b);
        System.out.println("toLowerCase " + Character.toLowerCase(b));
        System.out.println("isLowerCase " + Character.isLowerCase(b));

    }
}
