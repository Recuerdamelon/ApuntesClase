package POO.ClasesYObjetos;

public class Coche {
    // Atributos = caracterÃ­sticas
    String marca;
    String modelo;
    String color;
    float potencia;
    float cilindrada;
    String combustible;
    float rpm = 0;
    private float km = 0;
    float deposito = 50.0f;
    static int numeroCoches;

    // MÃ©todos = comportamiento
    public float getKm(){
        return this.km;
    }

//    public void setKm(float km){
//        this.km = km;
//    }


    public float consumo(float kmRecorridos){
        return deposito/kmRecorridos*100;
    }

    public float consumo(float kmRecorridos, float repostado){
        return repostado/kmRecorridos*100;
    }

    public void viajar(float distancia){
        this.km += distancia;
    }
    public void arrancar(){rpm = 800;}

    public void acelerar(){}

    public void frenar(){}

    public void cambioMarcha(){}

    public void nombreCoche(){
        System.out.println("marca: " + this.marca);
        System.out.println("modelo = " + this.modelo);
        System.out.println("color = " + this.color);
        System.out.println("potencia = " + this.potencia);
        System.out.println("km = " + this.km);
    }

    static void emergencia(){
        System.out.println("Estoy llamando al 112");
    }
}
