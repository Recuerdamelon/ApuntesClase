package POO.ClasesYObjetos;

public class EjemploCoche {
    public static void main(String[] args) {
        Coche.emergencia();
        Coche.numeroCoches = 2;

        // "Instanciar"
        Coche miCoche = new Coche();
        Coche tuCoche = new Coche();
        //System.out.println("miCoche.rpm = " + miCoche.rpm);
        //System.out.println("miCoche.marca = " + miCoche.marca);

        // Dar valores a los atributos
        miCoche.marca = "Toyota";
        miCoche.modelo = "Yaris";
        miCoche.color = "Rojo";
        miCoche.cilindrada = 1.5f;
        miCoche.potencia = 120;
        miCoche.combustible = "Hibrido";
        miCoche.numeroCoches = 25;
        System.out.println("miCoche.numeroCoches = " + miCoche.numeroCoches);
        System.out.println("Coche.numeroCoches = " + Coche.numeroCoches);

        // dar/leer valor a un atributo privado (km)
        // miCoche.km = 23000; // NO
        // System.out.println("tuCoche.km = " + tuCoche.km); // NO
        // miCoche.setKm(25600); // No creamos el mÃ©todo setKm
        miCoche.viajar(1200.5f);
        miCoche.viajar(650);
        System.out.println("miCoche.getKm() = " + miCoche.getKm());
        miCoche.viajar(750.6f);
        System.out.println("miCoche.getKm() = " + miCoche.getKm());

        System.out.println("miCoche.marca = " + miCoche.marca);
        tuCoche.marca = "Volvo";
        tuCoche.modelo = "XC40";
        tuCoche.color = "Blanco";
        tuCoche.cilindrada = 1.8f;
        tuCoche.potencia = 150;
        tuCoche.combustible = "Diesel";
        System.out.println("tuCoche.numeroCoches = " + tuCoche.numeroCoches);

        // Uso del this
        tuCoche.nombreCoche();

        // Sobrecarga de mÃ©todos
        System.out.println("Consumo = " + tuCoche.consumo(800));
        System.out.println("Consumo = " + tuCoche.consumo(250,20));



    }
}
