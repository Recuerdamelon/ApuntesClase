package POO.ClasesYObjetos;

public class MetodosConstructores {
    public static void main(String[] args) {
        Coche1 cocheJuan = new Coche1();
        System.out.println(cocheJuan.toString());
        System.out.println("------------------");
        Coche1 cochePatricia = new Coche1("Ford","Focus","Rojo",120,2000);
        System.out.println(cochePatricia.toString());
    }
}
