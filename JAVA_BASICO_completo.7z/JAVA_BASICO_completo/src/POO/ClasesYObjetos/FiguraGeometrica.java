package POO.ClasesYObjetos;

public class FiguraGeometrica {
    // Atributos
    int dimensiones; // 3D o 2D
    long largo;
    long ancho;
    long radio;
    // ...
    final double PI = 3.1415926;

    public void perimetro(){
        // PI
    }
}
