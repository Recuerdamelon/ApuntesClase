package POO.ClasesYObjetos;

public class Coche1 {
    // Atributos = caracterÃ­sticas
    private String marca;
    private String modelo;
    private String color;
    float potencia;
    float cilindrada;
    String combustible;
    float rpm;
    private float km;
    private float deposito;
    static int numeroCoches;

    // Constructor
    public Coche1(){
        this.rpm = 1;
        this.km = 1;
        this.deposito = 35;
    }


    // Constructores generados

    public Coche1(String marca) {
        this.marca = marca;
    }

    public Coche1(String marca, String modelo) {
        //this.marca = marca;
        this(marca);
        this.modelo = modelo;
    }

    public Coche1(String marca, String modelo, String color) {
//        this.marca = marca;
//        this.modelo = modelo;
        this(marca, modelo);
        this.color = color;
    }

    public Coche1(String marca, String modelo, String color, float potencia) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
        this(marca, modelo, color);
        this.potencia = potencia;
    }

    public Coche1(String marca, String modelo, String color, float potencia, float cilindrada) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
//        this.potencia = potencia;
        this(marca, modelo, color, potencia);
        this.cilindrada = cilindrada;
    }

    public Coche1(String marca, String modelo, String color, float potencia, float cilindrada, String combustible) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
//        this.potencia = potencia;
//        this.cilindrada = cilindrada;
        this(marca, modelo, color, potencia, cilindrada);
        this.combustible = combustible;
    }

    public Coche1(String marca, String modelo, String color, float potencia, float cilindrada, String combustible, float rpm) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
//        this.potencia = potencia;
//        this.cilindrada = cilindrada;
//        this.combustible = combustible;
        this(marca, modelo, color, potencia, cilindrada, combustible);
        this.rpm = rpm;
    }

    public Coche1(String marca, String modelo, String color, float potencia, float cilindrada, String combustible, float rpm, float km) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
//        this.potencia = potencia;
//        this.cilindrada = cilindrada;
//        this.combustible = combustible;
//        this.rpm = rpm;
        this(marca, modelo, color, potencia, cilindrada, combustible, rpm);
        this.km = km;

    }

    public Coche1(String marca, String modelo, String color, float potencia, float cilindrada, String combustible, float rpm, float km, float deposito) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.color = color;
//        this.potencia = potencia;
//        this.cilindrada = cilindrada;
//        this.combustible = combustible;
//        this.rpm = rpm;
//        this.km = km;
        this(marca, modelo, color, potencia, cilindrada, combustible, rpm, km);
        this.deposito = deposito;
    }





    // Getters/Setters

    public float getDeposito() {
        return deposito;
    }

    public void setDeposito(float deposito) {
        this.deposito = deposito;
    }

    public float getKm() {
        return km;
    }

//    public void setKm(float km) {
//        this.km = km;
//    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // MÃ©todos = comportamiento
    public float consumo(float kmRecorridos){
        return deposito/kmRecorridos*100;
    }

    public float consumo(float kmRecorridos, float repostado){
        return repostado/kmRecorridos*100;
    }

    public void viajar(float distancia){
        this.km += distancia;
    }
    public void arrancar(){rpm = 800;}

    public void acelerar(){}

    public void frenar(){}

    public void cambioMarcha(){}

    public void nombreCoche(){
        System.out.println("marca: " + this.marca);
        System.out.println("modelo = " + this.modelo);
        System.out.println("color = " + this.color);
        System.out.println("combustible = " + this.combustible);
        System.out.println("potencia = " + this.potencia);
        System.out.println("km = " + this.km);
        System.out.println("deposito = " + this.deposito);
    }

    static void emergencia(){
        System.out.println("Estoy llamando al 112");
    }

    // toString personaliza


    @Override
    public String toString() {
        return "Coche1{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", color='" + color + '\'' +
                ", potencia=" + potencia +
                ", cilindrada=" + cilindrada +
                ", combustible='" + combustible + '\'' +
                ", rpm=" + rpm +
                ", km=" + km +
                ", deposito=" + deposito +
                '}';
    }
}
