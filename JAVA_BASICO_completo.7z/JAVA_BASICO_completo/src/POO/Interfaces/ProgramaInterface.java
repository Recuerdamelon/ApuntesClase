package POO.Interfaces;

public class ProgramaInterface {
    public static void main(String[] args) {
        DemoInterfaz objetoPepe = new DemoInterfaz();
        objetoPepe.nombre = "Eduardo";
        objetoPepe.metodoInterfaz1();
        objetoPepe.imprimeNombre();
        objetoPepe.metodoInterfaz2();
    }
}
