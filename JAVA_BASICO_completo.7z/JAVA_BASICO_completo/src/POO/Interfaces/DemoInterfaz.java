package POO.Interfaces;
public class DemoInterfaz implements Interface1, Interface2{
    String nombre;
    @Override
    public void metodoInterfaz1(){
        System.out.println("Constante1 = " + Constante1);
    }

    public void imprimeNombre(){
        System.out.println("this.nombre = " + this.nombre);
    }

    @Override
    public void metodoInterfaz2() {
        System.out.println("Constante2 = " + Constante2);
    }
}
