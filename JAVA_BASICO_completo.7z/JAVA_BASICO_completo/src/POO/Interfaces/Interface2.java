package POO.Interfaces;

public interface Interface2 {
    public static final int Constante2 = 587;
    public void metodoInterfaz2();
}
