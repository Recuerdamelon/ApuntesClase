package POO.Interfaces;

public interface Interface1 {
    public static final int Constante1 = 932;
    public void metodoInterfaz1();
}

