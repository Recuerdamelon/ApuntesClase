package POO.EnumPackageUMLyModificadores.EjemploFacturacion;

public class Factura {
    String fecha;
    Cliente cliente;
    Item[] items = new Item[3];
    //    double totalFactura;
//    double totalAPagar;
    double iva = 21;

    public double calculaTotalFactura(){
        double total = 0;
        for(Item linea:items){
            total += linea.getTotalItem();
        }
        return total;
    }

    public double calculaTotalAPagar(){
        return calculaTotalFactura() * (1+iva/100);
    }
}
