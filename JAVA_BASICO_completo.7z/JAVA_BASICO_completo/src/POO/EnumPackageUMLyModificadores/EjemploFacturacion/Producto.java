package POO.EnumPackageUMLyModificadores.EjemploFacturacion;

public enum Producto {
    CAMISETA("Camiseta",25.0),
    VAQUERO("PantalÃ³n Vaquero",50.0),
    CHAQUETA("Chaqueta de punto",35.95),
    ZAPATILLAS("Babuchas",8.60),
    NADA("",0);

    private String descripcion;
    private double precio;

    Producto(String descripcion, double precio) {
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public double getPrecio() {
        return precio;
    }

}
