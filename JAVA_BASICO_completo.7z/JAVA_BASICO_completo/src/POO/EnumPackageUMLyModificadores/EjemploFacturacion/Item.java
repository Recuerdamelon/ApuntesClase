package POO.EnumPackageUMLyModificadores.EjemploFacturacion;

public class Item {
    private int uds;
    private String descripcion;
    private double precio;
    private double totalItem;

    public void calculaTotalItem(){
        this.totalItem = this.uds * this.precio;
    }

    public Item(int uds, String descripcion, double precio) {
        this.uds = uds;
        this.descripcion = descripcion;
        this.precio = precio;
        calculaTotalItem();
    }

    public double getTotalItem() {
        return totalItem;
    }
    @Override
    public String toString() {
        return uds + "     " +  descripcion + "       " + precio + "     "+ totalItem ;
    }
}
