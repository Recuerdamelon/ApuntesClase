package POO.EnumPackageUMLyModificadores.EjemploFacturacion;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Facturacion {
    public static void main(String[] args) {
        Factura objFactura = new Factura();

//        // Introducir los datos del cliente por consola
//        // Crear un objeto del tipo cliente con esos datos
//        // Aplicar el mÃ©todo toString()
//
        Scanner entrada = new Scanner(System.in);
        System.out.println("Datos cliente: ");
        System.out.print("Nombre: ");
        String nombre = entrada.nextLine();
        System.out.print("DirecciÃ³n: ");
        String direccion = entrada.nextLine();
        System.out.print("DNI: ");
        String dni = entrada.nextLine();
        System.out.print("email: ");
        String email = entrada.nextLine();

        Cliente cliente = new Cliente(nombre,dni,direccion,email);

        objFactura.cliente = cliente;

        //System.out.println(cliente.toString());

        // Introducir la cantidad y el producto comparado (hasta 3 productos)
        // Cada producto en un objeto Item
        // Los items se almacenan en un array de Items (3) en la factura


        System.out.println("Productos: ");
        for(int i = 0; i < 3; i++) {
            System.out.print("uds: ");
            int uds = Integer.parseInt(entrada.nextLine());
            System.out.print("prenda: ");
            String prenda = entrada.nextLine();

            Producto producto;

            switch(prenda.toUpperCase()){
                case "CAMISETA":
                    producto = Producto.CAMISETA;
                    break;
                case "VAQUERO":
                    producto = Producto.VAQUERO;
                    break;
                case "CHAQUETA":
                    producto = Producto.CHAQUETA;
                    break;
                case "ZAPATILLAS":
                    producto = Producto.ZAPATILLAS;
                    break;
                default:
                    producto = Producto.NADA;
            }

            Item linea = new Item(uds,producto.getDescripcion(), producto.getPrecio());

            objFactura.items[i] = linea;
        }

        // Imprimir, poner fecha y calcular los importes
        // Fecha
        Date fecha = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        objFactura.fecha = formato.format(fecha);

        System.out.println("Fecha de factura: " + fecha);
        System.out.println(objFactura.cliente.toString());
        for(Item linea:objFactura.items){
            System.out.println(linea.toString());
        }

        System.out.println("Total factura: " + objFactura.calculaTotalFactura());
        System.out.println("Total a pagar: " + objFactura.calculaTotalAPagar());
    }
}
