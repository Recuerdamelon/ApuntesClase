package POO.EnumPackageUMLyModificadores.EjemploFacturacion;

public class Cliente {
    private String nombre;
    private String dni;
    private String direccion;
    private String email;

    public Cliente(String nombre, String dni, String direccion, String email) {
        this.nombre = nombre;
        this.dni = dni;
        this.direccion = direccion;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Cliente:\n"
                + nombre + "\n" +
                direccion + "\n" +
                "DNI " + dni + "\n" +
                "email: '" + email;
    }
}
