package POO.EnumPackageUMLyModificadores.Ejercicios;

public enum TipoAutomovil {
    SEDAN("Sedan","Mediano",4),
    STATION_WAGON("Familiar","Grande",5),
    HATCHBACK("Hatchback","Compacto",5),
    PICKUP("Pickup","Furgoneta",4),
    COUPE("CoupÃ©","Deportivo",2),
    SUV("SUV","Todo terreno deportivo",5);

    // Nombre y tipo de atributos o parÃ¡metros
    private final String nombre;
    private final String descripcion;
    private final int numeroPuertas;


    // Constructor
    TipoAutomovil(String nombre, String descripcion, int numeroPuertas) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.numeroPuertas = numeroPuertas;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getNumeroPuertas() {
        return numeroPuertas;
    }

}
