package POO.EnumPackageUMLyModificadores.Ejercicios;

public class EjemploEnum {
    public static void main(String[] args) {
        Color miColor = Color.VERDE;
        System.out.println("miColor = " + miColor);

        // recorrer emun
        for(Color elColor:Color.values()){
            System.out.println("elColor = " + elColor);
        }

        // Toma de decisiones - Control de flujo
        if(miColor == Color.AZUL){
            System.out.println("El color es azul");
        }else{
            System.out.println("El color no es azul");
        }

        // NotaciÃ³n 1
        switch (miColor) {
            case BLANCO -> {
                System.out.println("Es Blanco");
                System.out.println("OTRA");
            }
            case VERDE -> {
                System.out.println("Es Verde");
                System.out.println("Una");
            }
        }

        // NotaciÃ³n 2
        switch (miColor){
            case BLANCO :
                System.out.println("Es Blanco");
                System.out.println("OTRA");
                break;
            case VERDE :
                System.out.println("Es Verde");
                System.out.println("Una");
                break;

        }

    }
}
