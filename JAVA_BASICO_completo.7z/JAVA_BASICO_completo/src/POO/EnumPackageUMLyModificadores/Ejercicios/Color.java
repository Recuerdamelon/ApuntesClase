package POO.EnumPackageUMLyModificadores.Ejercicios;

public enum Color {
    ROJO,
    VERDE,
    AZUL,
    AMARILLO,
    BLANCO,
    NEGRO
}
