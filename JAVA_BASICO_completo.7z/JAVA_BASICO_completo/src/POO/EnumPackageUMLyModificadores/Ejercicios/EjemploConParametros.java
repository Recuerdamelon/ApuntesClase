package POO.EnumPackageUMLyModificadores.Ejercicios;

public class EjemploConParametros {
    public static void main(String[] args) {
        TipoAutomovil miCoche = TipoAutomovil.STATION_WAGON;
        System.out.println("miCoche = " + miCoche);
        System.out.println("miCoche.getNombre() = " + miCoche.getNombre());
        System.out.println("miCoche.getDescripcion() = " + miCoche.getDescripcion());
        System.out.println("miCoche.getNumeroPuertas() = " + miCoche.getNumeroPuertas());
        System.out.println("--------------------------------");

        Amigos companiero = Amigos.ANTONIO;
        System.out.println("miCoche = " + companiero);
        System.out.println("miCoche.getNombre() = " + companiero.getNombre());
        System.out.println("miCoche.getTelefono() = " + companiero.getTelefono());
        System.out.println("miCoche.getEmail() = " + companiero.getEmail());
        System.out.println("--------------------------------");

        Persona eduardo = new Persona("Eduardo","Corral MuÃ±oz","eduardo@gmail.com");
        eduardo.setMejorAmigo(Amigos.MARTA);
        System.out.println("Mis Datos = " + eduardo.getNombre() + " " + eduardo.getApellidos()
                + " "+eduardo.getEmail()+" "+eduardo.getMejorAmigo().getNombre());
    }
}
