package POO.EnumPackageUMLyModificadores.Ejercicios;

public enum Amigos {
    // NOMBRE y como parametros nombre completo, telÃ©fono y email
    PEPE("JosÃ© MartÃ­n","629876543","pepe@eoi.es"),
    MARTA("Marta Suarez","629666643","marta@eoi.es"),
    MARIA("MarÃ­a Martinez","608652743","maria@eoi.es"),
    ANTONIO("Antonio Sanz","657112233","antonio@eoi.es");

    private final String nombre;
    private final String telefono;
    private final String email;

    Amigos(String nombre, String telefono, String email) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }
}
