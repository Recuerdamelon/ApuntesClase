package POO.HerenciaPolimorfismoAbstraccion.HerenciaYPolimorfismo;

public class Coche extends Vehiculo{
    private String modelo = "Mustang";

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
