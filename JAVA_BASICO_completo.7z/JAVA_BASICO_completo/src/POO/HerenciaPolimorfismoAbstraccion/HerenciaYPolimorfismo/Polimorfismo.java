package POO.HerenciaPolimorfismoAbstraccion.HerenciaYPolimorfismo;

public class Polimorfismo {
    public static void main(String[] args) {
        Animal miAnimal = new Animal();
        Cerdo miCerdo = new Cerdo();
        Perro miPerro = new Perro();

        miAnimal.sonido();
        miCerdo.sonido();
        miPerro.sonido();
    }
}

class Animal{ // Superclase = clase padre
    String descripcion = "Soy un animal";
    public void sonido(){
        System.out.println("Sonido de aminal");
    }
}

class Perro extends Animal{ // Subclase = hija de Animal
    public void sonido(){
        this.descripcion = "Soy un perro";
        System.out.println("Guau Guau!");
    }
}

class Cerdo extends Animal{ // Subclase = hija de Animal
    public void sonido(){
        this.descripcion = "Soy un cerdo";
        System.out.println("gÃ¼i gÃ¼i!");
    }
}
