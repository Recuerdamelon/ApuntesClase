package POO.HerenciaPolimorfismoAbstraccion.HerenciaYPolimorfismo;

public class Super {
    public static void main(String[] args) {
        Persona miPersona = new Persona("Eduardo","Corral");
        System.out.println(miPersona.toString());
        System.out.println("---------------------------");
        Alumno miAlumno = new Alumno("Eduardo","Corral","EOI");
        System.out.println(miAlumno.toString());
        miAlumno.metodoDelPadre();
    }
}

class Persona{
    protected String nombre;
    protected String apellido;

    public void metodoDelPadre(){
        System.out.println("Soy tu padre!");
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                '}';
    }

    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
}

class Alumno extends Persona{
    private String centro;

    @Override
    public void metodoDelPadre() {
        //System.out.print(personaje + " ");
        super.metodoDelPadre();
        System.out.println(" y lo sabes!");
    }

    public Alumno(String nombre, String apellido, String centro) {
        super(nombre, apellido);
        this.centro = centro;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", centro='" + centro + '\'' +
                '}';
    }
}
