package POO.HerenciaPolimorfismoAbstraccion.HerenciaYPolimorfismo;

public class EjemploCoche {
    public static void main(String[] args) {
        Vehiculo miVehiculo = new Vehiculo();
        System.out.println("miVehiculo.marca = " + miVehiculo.marca);
        miVehiculo.claxon();

        System.out.println("------------------------");
        Coche miCoche = new Coche();
        System.out.println("miCoche.marca = " + miCoche.marca);
        System.out.println("miCoche.modelo = " + miCoche.getModelo());
//        miCoche.setMarca("Renault");
//        System.out.println("miCoche.marca = " + miCoche.marca);
        miCoche.claxon();
    }
}
