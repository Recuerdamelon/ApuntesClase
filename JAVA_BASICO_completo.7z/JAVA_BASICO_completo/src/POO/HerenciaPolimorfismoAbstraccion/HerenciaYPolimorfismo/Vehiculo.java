package POO.HerenciaPolimorfismoAbstraccion.HerenciaYPolimorfismo;

public class Vehiculo {
    protected String marca = "Ford";

    public void claxon(){
        System.out.println("Tuut, tuut!");
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
}
