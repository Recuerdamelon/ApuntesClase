package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;

public class Cuadrado extends FiguraGeometrica{
    double lado;

    @Override //Override, sobrescribe el valor que tiene en el método abstract implementado
    public void perimetro() {
        System.out.println("perimetro = " + (4 * lado));
    }

    @Override
    public void superficie() {
        System.out.println("superficie = " + (lado * lado));
    }

    @Override
    public void grafico() {
        System.out.println("dibuja cuadrado");
    }
}
