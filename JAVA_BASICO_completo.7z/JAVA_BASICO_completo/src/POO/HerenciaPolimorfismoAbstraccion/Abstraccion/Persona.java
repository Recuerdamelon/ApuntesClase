package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;

abstract class Persona {
    // Atributos
    protected String nombre;
    protected String apellido;
    protected String email;
    // ...

    // Métodos abstractos
    abstract public void registro();
    abstract public void editar();
    abstract public void borra();

    // Método normal
    public String nombreCompleto(){
        return this.nombre + " " + this.apellido;
    }
}
