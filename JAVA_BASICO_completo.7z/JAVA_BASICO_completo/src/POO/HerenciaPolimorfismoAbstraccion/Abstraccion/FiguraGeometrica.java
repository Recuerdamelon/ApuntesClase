package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;

abstract class FiguraGeometrica {
    abstract public void perimetro();
    abstract public void superficie();
    abstract public void grafico();
}
