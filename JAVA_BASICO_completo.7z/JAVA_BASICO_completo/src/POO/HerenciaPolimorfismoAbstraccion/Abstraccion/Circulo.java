package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;

public class Circulo extends FiguraGeometrica{
    double radio;
    @Override//Override, sobrescribe el valor que tiene en el método abstract implementado
    public void perimetro() {
        System.out.println("perimetro = " + (2 * Math.PI * radio ));
    }

    @Override
    public void superficie() {
        System.out.println("perimetro = " + (Math.PI * radio * radio));
    }

    @Override
    public void grafico() {
        System.out.println("dibuja circulo");
    }
}
