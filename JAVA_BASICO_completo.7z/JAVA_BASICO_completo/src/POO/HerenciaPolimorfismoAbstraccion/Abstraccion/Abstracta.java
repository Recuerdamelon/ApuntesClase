package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;
//NO TE CONFUNDAS POR EL NOMBRE, ESTO NO ES UNA CLASE ABSTRACTA,
// ES UNA CLASE PUBLIC QUE SE LLAMA ABSTRACTA

public class Abstracta {
    public static void main(String[] args) {
        // NO SE PUEDE instanciar un objeto de una clase abstracta
        // Persona miPersona = new Persona(); -NO-
        // Crear objeto desde subclase implementada de la abstracta
        HijaPersona miHijo = new HijaPersona();

        miHijo.nombre = "Eduardo"; //Atributos no presentes en la subclase, protegidos en...
                                    //...la superclase abstracta implementada
        miHijo.apellido = "Corral";
        System.out.println(miHijo.nombreCompleto());
        miHijo.editar(); //Puedo llamar a un objeto de la clase abstracta Persona
                        //desde el objeto de la clase HijaPersona pues la clase abstracta
                        //está implementada en la clase Persona

        System.out.println("----------------------------");

        Cuadrado miCuadrado = new Cuadrado();
        miCuadrado.lado = 21;
        miCuadrado.perimetro();
        miCuadrado.superficie();
        miCuadrado.grafico();

        System.out.println("----------------------------");

        Circulo miCirculo = new Circulo();
        miCirculo.radio = 5;
        miCirculo.perimetro();
        miCirculo.superficie();
        miCirculo.grafico();
    }
}
