package POO.HerenciaPolimorfismoAbstraccion.Abstraccion;

public class HijaPersona extends Persona{

    //LLAMAMOS a las CLASES ABSTRACTAS... Son como esquemas...
    // Te dan un guion de los elementos necesarios
    //... para el desarrollo de clases que tienen algo en común.
    @Override
    public void registro() {
        System.out.println("Registro");
    }

    @Override//Override, sobrescribe el valor que tiene en el método abstract implementado
    public void editar() {
        System.out.println("Editar");
    }

    @Override
    public void borra() {
        System.out.println("Borra");
    }
}
