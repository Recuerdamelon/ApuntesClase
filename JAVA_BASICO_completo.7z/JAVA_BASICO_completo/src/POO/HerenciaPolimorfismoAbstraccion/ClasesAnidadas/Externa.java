package POO.HerenciaPolimorfismoAbstraccion.ClasesAnidadas;

public class Externa {
    public int x = 5;

    public static void main(String[] args) {


    }

    class Interna{//Siendo private solo puedo trabajar dentro de la propia clase
        int y = 10;
        int k = x;

        public void unMetodo(){
            x = y;
        }
    }

    static class Interna2{//Siendo static no puedo referenciar objetos desde objetos externos a esta clase
        int z = 25;
    }
}
