package POO.HerenciaPolimorfismoAbstraccion.ClasesAnidadas;

public class Principal {
    public static void main(String[] args) {
        // Objeto clase externa
        Externa objetoExterno = new Externa();
        System.out.println("objetoExterno.x = " + objetoExterno.x);

        // Objeto clase interna
        Externa.Interna otro = objetoExterno.new Interna();
        System.out.println("otro.y = " + otro.y);
        otro.unMetodo();
        System.out.println("objetoExterno.x = " + objetoExterno.x);

        Externa.Interna objetoInterna = new Externa().new Interna();
        System.out.println("objetoInterna.y = " + objetoInterna.y);


        // Estatica interna2
        Externa.Interna2 objetoInterno2 = new Externa.Interna2();
        Externa objetoExterno2 = new Externa();
        //Externa.Interna2 objetoInterno3 = new objetoExterno2.Interna2();
        // llamar a una clase interna (anidada) de otra clase a través de un objeto creado en esta clase
        // externa cuando sea una clase de tipo STATIC
    }
}
