package Archivos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DemoArchivos {
    public static void main(String[] args) {
//        File archivo = new File("miarchivo.txt");
//        System.out.println("archivo = " + archivo.exists());

        // Definir objeto handler
        File archivo = new File("miarchivo.txt");

        // Crear archivo
        try{
            if(archivo.createNewFile()){//If Else... ¿Ya existe?...
                System.out.println("Archivo creado = " + archivo.getName());
            }else{
                System.out.println("el archivo " + archivo + " ya existe");
            }
            //System.out.println("Crea archivo = " + archivo.createNewFile());//Creado en la carpeta del proyecto
        }catch(IOException e){
            System.out.println("e.getMessage() = " + e.getMessage());
        }

        // Algunos métodos para archivos
        System.out.println("archivo.getPath = " + archivo.getPath());
        System.out.println("archivo.getAbsolutePath = " + archivo.getAbsolutePath());
        System.out.println("archivo.canWrite = " + archivo.canWrite());
        System.out.println("archivo.isDirectory = " + archivo.isDirectory());
        System.out.println("archivo.isFile = " + archivo.isFile());
        System.out.println("archivo.isHidden = " + archivo.isHidden());
        System.out.println("archivo.length = " + archivo.length());
        System.out.println("archivo.lastModified = " + archivo.lastModified());

        // Escribir
        String retornoCarro = "\r\n";
        try{
            FileWriter escribir = new FileWriter("miarchivo1.txt",true);
            escribir.write("Escribo una vez mÃ¡s en el archivo" + retornoCarro);
            escribir.close();
            System.out.println("Â¡Escritura correcta!");
        }catch(IOException e){
            System.out.println("e.getMessage() = " + e.getMessage());
        }

        // Leer
        try{
            File miArchivo = new File("miarchivo1.txt");
            Scanner leer = new Scanner(miArchivo);//para leer MÉTODO SCANNER del FileHandler
            while(leer.hasNextLine()) {//Método del scanner... While leer has next line....
                String linea = leer.nextLine();
                System.out.println("linea = " + linea);
            }
        }catch(FileNotFoundException e){
            System.out.println("e.getMessage() = " + e.getMessage());
        }

        // Borrar
        File arch = new File("pruebas");//FileHandler
        if(arch.exists()){
            System.out.println("arch = " + arch.delete());
            System.out.println("El archivo " + arch.getPath() + " ha sido eliminado");
        }else{
            System.out.println("El archivo " + arch.getPath() + " no existe");
        }

        System.out.println("arch = " + arch.delete());
    }
}
