package Archivos;
import java.io.File;

public class SistemaArchivos {
    static int nivel = 0;

    public static void main(String[] args) {

        listaContenido("C:\\Users\\juanc\\Documents\\curso_JAVA");
    }

    public static void listaContenido(String ruta){
        nivel++;//Everytime you get into the process increases a unity
        File carpeta = new File(ruta);
        File[] sistema = carpeta.listFiles();

        for(File archivo:sistema){
            if(archivo.isFile()) {//LLamamos al método separador nivel! Cada nivel 1 tabulador
                System.out.println(separador(nivel) +archivo.getName() + "\t\t\t" + archivo.length());
            }else{ // es carpeta
                System.out.println(separador(nivel) + archivo.getName());//con ------- carpetas
                listaContenido(archivo.getAbsolutePath());
            }
        }
        nivel--;//When arrives to a folder, exits and nivel-- backs to 0 and back to the for
    }

    public static String separador(int nivel){//Añadimos separador tabulador por cada nivel
        String separador = "";
        for(int i = 1; i < nivel; i++){
            separador += "\t";
        }
        return separador;
    }
}
