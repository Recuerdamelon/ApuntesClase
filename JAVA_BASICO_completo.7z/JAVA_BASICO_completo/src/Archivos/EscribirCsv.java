package Archivos;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirCsv {
    public static void main(String[] args) {
        String[][] usuarios = {{"Eduardo", "Corral", "ecorral.eoi.es"},
                {"Juan", "Perez", "jperez.eoi.es"},
                {"Marta", "Luna", "mluna.eoi.es"},
                {"MarÃ­a", "Martinez", "mmartinez.eoi.es"},
                {"JosÃ©", "GarcÃ­a", "jgarcia.eoi.es"}
        };

        String eol = "\r\n";

        try{
            FileWriter escribir = new FileWriter("miarchivo.csv",true);
            for(String[] usuario:usuarios) {
                String linea = usuario[0] + ";" + usuario[1] + ";"  + usuario[2] + eol;
                escribir.write(linea);
            }
            escribir.close();
            System.out.println("Â¡Escritura correcta!");
        }catch(IOException e){
            System.out.println("e.getMessage() = " + e.getMessage());
        }
    }
}
