package Archivos;

public class EnunciadoEjercicio {
    // 1 - Crear una clase Alumno con lo atributos que indica alumnos1.csv
    // 2 - Método lea todas las lineas del archivo alumnos1.csv e interpretar
    // la linea leida y separarla en los campos que contiene
    // asignado cada campo a un objeto Alumno
    // 3 - Almacenarlos en un Map con clave el Id del alumno
    // 4 - Método que introduciendo por consola un Id muestre todos los datos
    // del alumno por consola.
    // 5 - Método que introduciendo por consola el email haga lo mismo.
}
