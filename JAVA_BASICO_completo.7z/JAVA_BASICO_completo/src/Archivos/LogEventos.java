package Archivos;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LogEventos {
    // En una clase que maneje archivos o E/S por consola
    // cada vez que se produzca un error se almacene en un archivo
    // errors.log con el siguiente formato
    // 17/05/2022 18:45:32 ERROR descripción del error
    // Un método independiente



    public static void errorLog(Exception e, String origen){
        // Crear/Abrir el archivo errors.log
        // File archivo = new File("errors.log");
        try {
            FileWriter escribir = new FileWriter("errors.log", true);//append true -> si no existe lo auto genera
            // Datar el evento -> fecha y hora
            LocalDateTime fecha = LocalDateTime.now();
            // Formatear fecha y hora
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            // Datos del error - tipo y descripciÃ³n
            String descripcion = e.getCause() + " - " + e.getMessage() ;
            // Dar formato a la linea a escribir
            String linea = fecha.format(formato) + " ERROR: " + origen + " --> " + descripcion;
            // Escribir error en archivo errors.log
            escribir.write(linea + "\r\n");//RETORNO DE CARRO, pasa a la línea siguiente
            escribir.close();
        }catch(Exception err){
            System.out.println("err.getMessage() = " + err.getMessage());
        }
    }

    public static void analizaEventos(String tipo){
        // Filtrar los errores almacenados en errors.log por tipo y fecha

        LocalDateTime D = LocalDateTime.now();
        DateTimeFormatter F = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        if (tipo.contains("java.io.FileNotFoundException")) {
            try {
                FileWriter escribir = new FileWriter("errorstipe1.log", true);
                escribir.write(tipo + D.format(F) + "\r\n");
                escribir.close();

            } catch (IOException e) {
                System.out.println("e.getMessage() = " + e.getMessage());
            }
        } else if ((tipo.contains("java.lang.NumberFormatException"))) {
            try {
                FileWriter escribir = new FileWriter("errorstipe2.log", true);
                escribir.write(tipo + D.format(F) + "\r\n");
                escribir.close();

            } catch (IOException e) {
                System.out.println("e.getMessage() = " + e.getMessage());
            }
        } else {
            System.out.println("Nuevo error no registrado");
        }
    }
}

