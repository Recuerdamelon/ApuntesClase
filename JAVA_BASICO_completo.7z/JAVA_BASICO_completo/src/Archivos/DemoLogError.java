package Archivos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DemoLogError {
    public static void main(String[] args) {
        //Leer un archivo
        try{
            File miArchivo = new File("miArchivo2.txt");
            Scanner leer = new Scanner(miArchivo);
            while (leer.hasNextLine()){
                String linea = leer.nextLine();
                System.out.println("linea = " + linea);
            }
        }catch(FileNotFoundException e){
            System.out.println("e.getMessage() = " + e.getMessage());
            LogEventos.errorLog(e, "DemoErrorLog");
        }
    }
}
