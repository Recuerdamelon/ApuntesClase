package RegularExpressions;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DemoRegex {
    public static void main(String[] args) {
        String texto = "En lugar de la 8 Mancha de cuyo nombre" ;
        String patron = "mancha";

        busqueda(texto,patron);

        patron = "lugar|sitio|ubicacion";
        busqueda(texto,patron);

        patron = ".de";
        busqueda(texto,patron);

        patron = "^un";
        busqueda(texto,patron);

        patron = "nombre$";
        busqueda(texto,patron);

        patron = "\\s";
        busqueda(texto,patron);

        patron = "\\d";
        busqueda(texto,patron);

        patron = "\\bnombre";
        busqueda(texto,patron);

        patron = "[x-z]";
        busqueda(texto,patron);

        patron = "[5-9]";
        busqueda(texto,patron);

        // luggg
        patron = "lug{3}";
        busqueda(texto,patron);

        //Password
        texto = "4456Acb%";
        patron = "(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&+]).{8,}";
        busqueda(texto,patron);

        //Email
        texto = "eoi.eduardoc@corral.es";
        patron = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[_a-z0-9-]+(\\.[_a-z0-9-]{2,})";
        busqueda(texto,patron);
    }

    public static void busqueda(String texto, String patron){
        Pattern miPatron = Pattern.compile(patron,Pattern.CASE_INSENSITIVE);
        Matcher miMatcher = miPatron.matcher(texto);
        System.out.println("Busqueda (" + patron + ")-> " + miMatcher.find());
    }
}
