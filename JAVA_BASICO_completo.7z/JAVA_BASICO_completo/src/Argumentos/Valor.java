package Argumentos;

public class Valor {
    public static void main(String[] args) {
        int argumento = 45;
        System.out.println("main inicio - argumento = " + argumento);
        //int variable2 = miMetodo(argumento);
        argumento = miMetodo(argumento);
        //System.out.println("variable2 = " + variable2);
        System.out.println("main salida - argumento = " + argumento);
    }

    public static int miMetodo(int argumento){
        System.out.println("miMetodo inicio - argumento = " + argumento);
        argumento = 54;
        System.out.println("miMetodo salida - argumento = " + argumento);
        return argumento;
    }
}
