package Strings;

public class Generalidades {
    public static void main(String[] args) {
/*        // Declaraciones
        String nombre = new String("Eduardo");
        System.out.println("nombre = " + nombre);
        String apellido = "Corral";
        System.out.println("nombre1 = " + apellido);

        // "escapar" las comillas
        String bienvenida = "El nombre autentico de Pepe es \"Jose\"";
        System.out.println("bienvenida = " + bienvenida);

        // Concatenar
        System.out.println("Nombre completo = " + nombre + " " + apellido);
        String nombrecompleto = nombre + " " + apellido;
        System.out.println("nombrecompleto = " + nombrecompleto);*/

        // Comparar
        String uno = "Eduardo Corral";
        String dos = new String("Eduardo Corral");
        System.out.println("uno = " + uno);
        System.out.println("dos = " + dos);
        System.out.println("uno == dos -> " + (uno==dos)); // "Incorrecto"
        System.out.println("uno.equals(dos) = " + uno.equals(dos)); // Correcto
    }
}
