package Strings;

public class MetodosString {
    public static void main(String[] args) {
        String str1 = "  En un lugar de La Mancha de cuyo ";
        String str2 = "Pepe Muñoz";
        System.out.println("str2 = " + str2);
        String str3 = "PEPE";
        String str4 = "";
        String str5 = "     ";
        // Longitud
        System.out.println("Longitud = " + str1.length());
        // Igual
        System.out.println("Igual = " + str1.equals(str2));
        // Igual insensitivo
        System.out.println("Igual Insensitivo = " + str2.equalsIgnoreCase(str3));
        // Comparar con
        System.out.println("Comparar = " + str2.compareTo(str3));
        // Comparar con Insensitivo
        System.out.println("Comparar insensitivo = " + str2.compareToIgnoreCase(str3));
        // Eliminar espacios al inicio y final
        System.out.println("Con espacios = |" + str1 + "|");
        System.out.println("Sin espacios = |" + str1.trim() + "|");
        // Extraer un caracter determinado
        System.out.println("Extrae caracter 10 = " + str1.charAt(10));
        // Convertir en matriz
        char[] matriz = str1.toCharArray();
        System.out.println("matriz 10 = " + matriz[10]);
        // Extraer cadena de caracteres
        System.out.println("Extraer con inico y fin = " + str1.substring(0,9));
        System.out.println("Extraer desde un indice = " + str1.substring(9));
        // Buscar
        System.out.println("Buscar caracter 1Âª coincidencia = " + str1.indexOf('u'));
        System.out.println("Buscar caracter 2Âª coincidencia= " + str1.indexOf('u',6));
        System.out.println("Buscar palabra = " + str1.indexOf("lugar"));
        System.out.println("Buscar caracter Ãºltima coincidencia = " + str1.lastIndexOf('u'));
        // Si empieza por o termina por
        System.out.println("Empieza por En = " + str1.trim().startsWith("En"));
        System.out.println("Empieza por un = " + str1.trim().startsWith("un",3));
        System.out.println("Termina en yo = " + str1.trim().endsWith("yo"));
        // Concatenar strings
        System.out.println("Concatenar = " + str1 + " " + str2 + " " + str3);//tough way
        System.out.println("Concatenar = " + str1.concat(" ").concat(str2).concat(" ").concat(str3));
        // Está vacio?
        System.out.println("Vacio = " + str4.isEmpty());
        // Está en Blanco?
        System.out.println("Blanco = " + str5.isBlank());
        // Separar en una matriz
        String[] palabras = str1.trim().split(" ");
        System.out.println("palabra 4 (indice 3) = " + palabras[3]);
        String meses = "enero,febrero,marzo,abril,mayo,junio,julio";
        String[] nombreMes = meses.split(",");
        System.out.println("nombreMes 5 (indice 4) = " + nombreMes[4]);
        // Mayúsculas y minúsculas
        System.out.println("MayÃºsculas = " + str1.toUpperCase());
        System.out.println("MinÃºsculas = " + str1.toLowerCase());
        // Reemplazar
        System.out.println("Reemplazo = " + str1.replace("La Mancha","Castilla y LeÃ³n"));
        System.out.println("str1 = " + str1);
        str1 = str1.replace("La Mancha","Castilla y LeÃ³n");
        System.out.println("str1 = " + str1);
        // Contiene
        System.out.println("Contiene Castilla? " + str1.contains("Castilla"));
    }
}
