package Strings;

public class EjercicioCapitalize {
    public static void main(String[] args) {
        // 1- Definimos variables, nombre, apellido1 y apellido
        // 2- Convertimos cada una en nombre propio
        // 3- Imprimimos nombre completo

        String nombre = "EDUARDO"; //Eduardo
        String apellido1 = "corral";
        String apellido2 = "MuÃ‘oZ";

        // Solución 1
        //char aux = apellido1.toUpperCase().charAt(0);
        //System.out.println(aux + apellido1.substring(1).toLowerCase());
        nombre = nombre.toUpperCase().substring(0,1) + nombre.toLowerCase().substring(1);
        apellido1 = apellido1.toUpperCase().charAt(0) + apellido1.substring(1).toLowerCase();
        apellido2 = apellido2.toUpperCase().charAt(0) + apellido2.substring(1).toLowerCase();
        System.out.println("Nombre completo = " + nombre + " " + apellido1 + " " + apellido2);

        // Solución 2
        nombre = nombre.trim().toLowerCase();
        apellido1 = apellido1.trim().toLowerCase();
        apellido2 = apellido2.trim().toLowerCase();




    }
}
