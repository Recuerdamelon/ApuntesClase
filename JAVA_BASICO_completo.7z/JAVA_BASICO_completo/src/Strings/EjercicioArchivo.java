package Strings;

public class EjercicioArchivo {
    public static void main(String[] args) {
        // Dado un archivo mifoto.jpg
        // Imprimir por separado nombre y el tipo de archivo
        String archivo = "mifoto.jpg";

        // Solución 1
        String[] separado = archivo.split("\\.");//el punto es muy puñetero, hay que añadirle
                                                        // hasta dos barras invertidas
        System.out.println("nombre = " + separado[0]);
        System.out.println("extensiÃ³n = " + separado[1]);

        // Solución 2
        int punto = archivo.lastIndexOf(".");
        System.out.println("nombre = " + archivo.substring(0,punto));
        System.out.println("extensiÃ³n = " + archivo.substring(punto+1));//para que lo pase al imprimirlo en pantalla

        // Simplificando 2
        System.out.println("nombre = " + archivo.substring(0,archivo.lastIndexOf(".")));
        System.out.println("extensiÃ³n = " + archivo.substring(archivo.lastIndexOf(".")+1));

    }
}
