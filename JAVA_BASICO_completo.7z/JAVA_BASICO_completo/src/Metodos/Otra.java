package Metodos;

public class Otra {
    public static void main(String[] args) {
        int dato = Metodos.sumaRango(5,9);
        System.out.println("dato = " + dato);
    }
}
