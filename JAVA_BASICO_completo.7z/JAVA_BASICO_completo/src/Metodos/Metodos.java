package Metodos;

public class Metodos {
    public static void main(String[] args) {
//        bienvenida();
//        for(int i = 0; i<5; i++){
//            System.out.println("i = " + i);
//        }
//        bienvenida();
//        imprimeNombre("Eduardo",14);
        int resultado = suma(21,6);
//        System.out.println("resultado = " + resultado);
//
//        resultado = sumaRango(5,9);
//        System.out.println("resultado = " + resultado);
//
//        float resultFloat = media(2, 9);
//        System.out.println("resultado = " + resultFloat);
//        resultado = factorial(5);
//        System.out.println("resultado = " + resultado);

        // Sobrecarga
        System.out.println("resultado = " + suma(3,4));
        System.out.println("resultado = " + suma(3,4,7));
        System.out.println("resultado = " + suma(3.5, 5.6));
        System.out.println("resultado = " + suma(3.5, 5.9));

        // Varargs
        System.out.println("resultado = " + sumar(2,8,9,5,1));
        System.out.println("resultado = " + sumar(2.8,8.56,9,5.789445,1.25));
    }

    public static void bienvenida() {
        System.out.println("Â¡Hola, bienvenido al curso de Java!");
    }

    public static void imprimeNombre(String nombre, int edad) {
        System.out.print("El nombre es = " + nombre);
        System.out.println(" y tiene " + edad + " aÃ±os");
    }



    public static int sumaRango(int inicio, int fin){
        int suma = 0;
        for(int i = inicio; i <= fin; i++){
            suma += i;
        }
        return suma;
    }

    public static float media(int inicio, int fin){
//        // sumo valores
//        int suma = sumaRango(inicio,fin);
//        // dividir por el nÃºmero total de valores
//        int valores = fin - inicio;
//        float media = (float)suma/valores;
//        return media;
        return (float)sumaRango(inicio,fin)/(fin - inicio);
    }

    public static int factorial(int numero){
        int resultado = 1;
        for(int i = 1; i <= numero; i++){
            //resultado = resultado * i;
            resultado *= i;
        }
        return resultado;
    }

    // Sobrecarga de mÃ©todos

    public static int suma(int a, int b){
        return a + b;
    }

    public static int suma(int a, int b, int c){
        return a + b + c;
    }

    public static double suma(double a, double b){
        return a + b;
    }

    // Varargs
    public static int sumar(int ... numero){
        int resultado = 0;
        for(int i = 0; i < numero.length; i++){
            resultado += numero[i];
        }
        return resultado;
    }

    public static double sumar(double ... numero){
        double resultado = 0;
        for(int i = 0; i < numero.length; i++){
            resultado += numero[i];
        }
        return resultado;
    }
}
