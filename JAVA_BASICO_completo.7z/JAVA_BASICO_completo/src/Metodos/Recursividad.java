package Metodos;

public class Recursividad {
    public static void main(String[] args) {
        int resultado = suma(5);
        System.out.println(resultado);
    }

    // Suma del 0 al numero indicado
    public static int suma(int numero){
        if(numero > 0){
            return numero + suma(numero-1);
        }else{
            return 0;
        }
    }
    //                            llamadas                  retornos
    // suma(5)               1Âª     5 + suma(4)      5Âº 5+10 = 15
    // suma(4)               2Âª     4 + suma(3)      4Âº 4+6 = 10
    // suma(3)               3Âª     3 + suma(2)      3Âº 3+3 = 6
    // suma(2)               4Âª     2 + suma(1)      2Âº 2+1 = 3
    // suma(1)               5Âª     1 + suma(0)      1Âº 1+0 = 1
    // suma(0)               6Âª     0
}
