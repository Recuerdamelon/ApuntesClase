package Colecciones;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class DemoHashSet {
    public static void main(String[] args) {
        HashSet<Integer> numeros = new HashSet<Integer>();
        // Agregar
        numeros.add(4);
        numeros.add(5);
        numeros.add(12);
        numeros.add(7);
        numeros.add(9);
        recorrer(numeros);

        // eliminar
        numeros.remove(7);
        recorrer(numeros);

        numeros.add(11);
        recorrer(numeros);

        // Borrar todo
        System.out.println("numeros.isEmpty() = " + numeros.isEmpty());
        numeros.clear();
        System.out.println("numeros.isEmpty() = " + numeros.isEmpty());

    }

    public static void recorrer(HashSet<Integer> num){
        for(Integer n:num){
            System.out.println("n = " + n);
        }
        System.out.println("------------------------");
    }

    public static void recorreIterator(ArrayList<Integer> num){
        // Iterator
        Iterator<Integer> iter = num.iterator();
        while(iter.hasNext()){
            System.out.println("iter.next() = " + iter.next());
        }
    }
}
