package Colecciones;
import javax.swing.*;
import java.util.HashMap;

public class EjercicioHashMap {
    // partiendo de una lista de email -> usuario
    // crear un mÃ©todo que localice el email introduciendo el nombre

    public static void main(String[] args) {
        // Leer nombre (String)
        String nombre;
        nombre = JOptionPane.showInputDialog(null,"Introduce un nombre");

        HashMap<String,String> emails = new HashMap<>();
        // OpciÃ³n 1
//        emails.put("Juan","juan@eoi.es");
//        emails.put("Alicia","alicia@eoi.es");
//        emails.put("Aitor","aitor@eoi.es");
//        emails.put("Fran","fran@eoi.es");
//        emails.put("Teresa","teresa@eoi.es");
//
//        System.out.println("emails = " + buscaEmail1(nombre,emails));
        // OpciÃ³n 2
        emails.put("juan@eoi.es","Juan");
        emails.put("alicia@eoi.es","Alicia");
        emails.put("aitor@eoi.es","Aitor");
        emails.put("fran@eoi.es","Aitor");
        emails.put("teresa@eoi.es","Teresa");
        buscaEmail2(nombre,emails);
    }

    public static String buscaEmail1(String nombre, HashMap<String,String> mapa){
        if(mapa.get(nombre) != null){
            return mapa.get(nombre);
        }else{
            return "No encontrado";
        }
    }

    public static void buscaEmail2(String nombre, HashMap<String,String> mapa){
        mapa.forEach((email, usuario) -> {
            if(usuario.equals(nombre)){
                System.out.println("email = " + email);
            }
        });
    }
}