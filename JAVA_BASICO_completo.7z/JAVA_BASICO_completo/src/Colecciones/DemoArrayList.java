package Colecciones;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class DemoArrayList {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<Integer>();

        // Agregar elementos
        numeros.add(3);
        numeros.add(5);
        numeros.add(7); //2
        numeros.add(9);
        numeros.add(3);
        numeros.add(2);
        numeros.add(4);

        System.out.println("numeros.size() = " + numeros.size());
        // Recorrer ArrayList
//        for(int i = 0; i < numeros.size(); i++){
//            System.out.println("numeros.get(" + i + ") = " + numeros.get(i));
//        }
//        System.out.println("------------------------------------");
//        for(Integer valor:numeros ){
//            System.out.println("valor = " + valor);
//        }
        recorrer(numeros);

        System.out.println("------------------------------------");

        // Agregar un elemento en un indice determinado
        numeros.add(2,11);

        System.out.println("numeros.size() = " + numeros.size());
//        for(int i = 0; i < numeros.size(); i++){
//            System.out.println("numeros.get(" + i + ") = " + numeros.get(i));
//        }
        recorrer(numeros);

        // Modificar el valor de un elemento en un indice determinado
        numeros.set(1,23);
        recorrer(numeros);

        // Eleminar un elemento determiando
        numeros.remove(2);
        recorrer(numeros);

        // Buscar elemento
        System.out.println("numeros.indexOf(3) = " + numeros.indexOf(3));
        System.out.println("numeros.lastIndexOf(3) = " + numeros.lastIndexOf(3));
        System.out.println("numeros.indexOf(57) = " + numeros.indexOf(57));

        // Ordenar
        Collections.sort(numeros);
        recorrer(numeros);


        // Contiene un elemento
        System.out.println("numeros.contains(7) = " + numeros.contains(7));
        System.out.println("numeros.contains(57) = " + numeros.contains(57));

        // Recorrer con iterator
        recorreIterator(numeros);

        // Eliminar todo
        System.out.println("numeros.isEmpty() = " + numeros.isEmpty());
        numeros.clear();
        System.out.println("numeros.isEmpty() = " + numeros.isEmpty());
        recorrer(numeros);

    }

    public static void recorrer(ArrayList<Integer> num) {
        for(int i = 0; i < num.size(); i++){
            System.out.println("num.get(" + i + ") = " + num.get(i));
        }
        System.out.println("------------------------------------");
    }

    public static void recorreIterator(ArrayList<Integer> num){
        // Iterator
        Iterator<Integer> iter = num.iterator();

        while(iter.hasNext()){
            System.out.println("iter.next() = " + iter.next());
        }
    }
}
