package com.example.demo;

import com.example.demo.entity.People;
import com.example.demo.repository.PeopleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;
import java.util.stream.Collectors;

@EnableAutoConfiguration
@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
	private static Logger logger = LoggerFactory.getLogger(DemoApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Autowired
	private PeopleRepository peopleRepository;

	@Override
	public void run(String... args){
		this.peopleRepository.findAll().stream().forEach(e -> logger.info(e.getName()));
		/*List<People> cosas = this.peopleRepository.findAll().stream().collect(Collectors.toList());
		for (People e: cosas) {
			System.out.println(e.getName());
		}*/
	}
}
