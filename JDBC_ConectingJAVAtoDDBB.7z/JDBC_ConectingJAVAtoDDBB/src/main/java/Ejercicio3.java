import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

///////////////QUERIES DE DATOS SELECCIONADOS POR EL USUARIO; INPUT DE CONSOLA/////////////

public class Ejercicio3 {
//Repetimos la conexión de Ejercicio1 y Ejercicio2...
    public static void main(String... args) throws SQLException, IOException, ParseException {
        final String url = "jdbc:mysql://127.0.0.1:3306/base";
        final String user = "root";
        final String password = "1234";

        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println(String.format("[DEBUG] Already Connected to  %s", url));

        //BufferedReader método de scanner de datos introducidos por consola (similar a Scanner pero sincronizado, más rápido y solo aplicable para Strings)
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the person's starting date");
        final String startingDate = bufferedReader.readLine();
        System.out.println("Enter the person's ending date");
        final String endingDate = bufferedReader.readLine();

        //PreparedStatement: Permite un Statement con datos introducidos por el usuario o programa
                                                                    // Los datos input ocupan los espacios del símbolo"?", en este caso (2)? ...
        PreparedStatement preparedstatement = connection.prepareStatement("SELECT * FROM people WHERE created_date BETWEEN ? AND ?;");
        //... preparedstatement.setString ( "?" parameter index 1 y 2 son los, BufferedReader startingDate y endingDate
        preparedstatement.setString(1, startingDate);
        preparedstatement.setString(2, endingDate);

        //Print del resultado...
        //Enunciado de los valores introducidos por el usuario como parámetros del Query
        System.out.println(String.format("Todas las personas creadas entre el %s y el %s", startingDate, endingDate));
        //Llamada al método printPeople definido más abajo
        printPeople(preparedstatement.executeQuery()); //No hay statement en el executeQuery() already prepareStatement before

        ////////////////////////OTRO EJEMPLO DE PREPARED STATEMENT...
        System.out.println("--------------------------apartado b---------------");
        System.out.println("Enter the planet name");
        final String planetName = bufferedReader.readLine();

        System.out.println(String.format("Todas las personas que viven en un planeta que empiece por '%s'", planetName));

        PreparedStatement statement2 = connection
                .prepareStatement("SELECT pe.* FROM people pe, planet pl WHERE pe.planet_id = pl.id AND pl.name LIKE ?");
        statement2.setString(1, String.format("%s%%", planetName));
        printPeople(statement2.executeQuery());

        //Always close
        connection.close();
    }

    //Método printPeople (Atributos ResultSet de Statements o PreparedStatements){
    // Bucle while (resulSet tenga contenido){Imprime los valores de el resulSet deseados}
    // }
    private static void printPeople(ResultSet resultSet) throws SQLException {
        while (resultSet.next()) {
            System.out.println(
                    String.format("Nombre: %s, Año: %s" //De nuevo String.format("Nombre: %s, Año:%s) dónde %s es el String obtenido (get) del sout
                            , resultSet.getString("name")
                            , resultSet.getString("birth_year")));
        }
    }
}
