import java.sql.*;

//
public class Ejercicio1 {

        public static void main(String... args) throws SQLException {
            // Método de la clase al que le pasamos la URL de conexión con MySQL DDBB, el usuario y la contraseña
            final String url = "jdbc:mysql://127.0.0.1:3306/base";//jdbc(aplicación de Spring)://(dirección del puerto máquina)/"nombre de la DDBB"
            final String user = "root";
            final String password = "1234";

            //Set conexión con DDBB mediante el método "Connection" del package "java.sql.*" al que le pasamos los atributos necesarios para la conexión
            Connection connection = DriverManager.getConnection(url, user, password);
            //sout a line if the project is "Already connected to %s <-(url)"
            System.out.println(String.format("Already Connected to  %s", url));

            //Llamamos al método Statement del package para habilitar consultas en la DDBB MySQL
            Statement statement = connection.createStatement();
            //Método Resulset del package que recoge la consulta (Statement) directamente en lenguaje MySQL mediante el método".executeQuery"
            ResultSet resultSet = statement.executeQuery("SELECT * FROM PEOPLE");
            //Bucle while...
            while (resultSet.next()) { //... while resulSet lea lineas...
                                        //INTERESANTE Uso del %tipo para introducir souts
                                        //String.format()
                //...imprime las columnas "name" y "birth_year" de nuestra DDBB
                System.out.print(String.format("Nombre: %s, Nacimiento: %s"
                        , resultSet.getString("name")
                        , resultSet.getString("birth_year")));
                System.out.println(" ");

            }
            //¡¡MUY IMPORTANTE!! Cerrar la conexión acabada la gestión del DDBB
            connection.close();
        }
    }

    //STRING BUILDER Crea un único String con el resultado
    //String x = "Hola ";
//
//StringBuilder stringBuilder = new StringBuilder();
//
//stringBuilder.append(x);
//
//for (int i = 0; i < 1000; i++) {
//
//    stringBuilder.append("Manolo");
//
//}
//
//System.out.println(stringBuilder.toString());
