import java.sql.*;

public class Ejercicio2 {
    //Al igual que el "Ejercicio1.java", atributos de conexión y método Connection con la DDBB
    public static void main(String... args) throws SQLException {
        final String url = "jdbc:mysql://127.0.0.1:3306/base";
        final String user = "root";
        final String password = "1234";

        Connection connection = DriverManager.getConnection(url, user, password);
        System.out.println(String.format("Already Connected to  %s", url));

        //Statement method para habilitar consultas...
        Statement statement = connection.createStatement();

        //CONSULTAS MySQL
        ResultSet resultSet = statement.executeQuery(
                "SELECT * FROM people WHERE DATE (created_date) " +
                        "BETWEEN '2014-12-15' AND '2014-12-20'");
        printPeople(resultSet);

        System.out.println("***********************************************");
        ResultSet resultSet2 = statement.executeQuery(
                "SELECT * FROM people WHERE planet_id " +
                        "IN (SELECT id FROM planet WHERE name LIKE \"D%\") " +
                        "ORDER BY name ASC");
        printPeople(resultSet2);

        System.out.println("***********************************************");
        ResultSet resultSet3 = statement.executeQuery(
                //Consulta MySQL "count()"... Investigar posibles consultas en Internet
                "SELECT count(*) AS total FROM people WHERE planet_id " +
                        "IN (SELECT id FROM planet WHERE name = \"Tatooine\")");
        //Usamos bucle pues en el método creado pedimos getString y aquí tenemos un Int
        while (resultSet3.next()) {
            System.out.println(resultSet3.getInt("total"));
        }


        //Siempre CLOSE CONNECTION after queries
        connection.close();
    }


    //Ojo! Creamos un método para no repetir el bucle while con cada Statement
    private static void printPeople (ResultSet resultSet) throws SQLException {
        while (resultSet.next()){
            System.out.println(
                    String.format ("Nombre: %s, Nacimiento: %s"
                    , resultSet.getString("name")
                    ,resultSet.getString("birth_year"))
            );
        }
    }
}
